/* ═══════════════════════════════════════════
   AC BROWSER — APP LOGIC
   ═══════════════════════════════════════════ */

'use strict';

// ── State ─────────────────────────────────────────────────────────────────────
const state = {
  tabs: [],
  activeTab: 0,
  isPrivate: false,
  settings: {
    searchEngine: 'duckduckgo',
    adblock: true,
    theme: 'system',
  },
  blockedCount: 0,
  history: [],
  bookmarks: [],
  downloads: [],
  currentPage: 'home', // home | browser | bookmarks | history | downloads | settings
};

// ── Storage helpers ───────────────────────────────────────────────────────────
const DB = {
  get: (key, fallback = null) => {
    try { const v = localStorage.getItem('acb_' + key); return v ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  set: (key, val) => {
    try { localStorage.setItem('acb_' + key, JSON.stringify(val)); } catch {}
  },
};

// ── Search engines ────────────────────────────────────────────────────────────
const ENGINES = {
  google: 'https://www.google.com/search?q=',
  bing: 'https://www.bing.com/search?q=',
  duckduckgo: 'https://html.duckduckgo.com/html/?q=',
};

// ── Ad block domain list ──────────────────────────────────────────────────────
const AD_DOMAINS = new Set([
  'doubleclick.net','googlesyndication.com','googleadservices.com',
  'google-analytics.com','facebook.net','connect.facebook.net',
  'analytics.twitter.com','amazon-adsystem.com','advertising.com',
  'adnxs.com','outbrain.com','taboola.com','criteo.com','criteo.net',
  'rubiconproject.com','pubmatic.com','openx.net','smartadserver.com',
  'appnexus.com','scorecard research.com','quantserve.com','hotjar.com',
  'mixpanel.com','amplitude.com','segment.com','moatads.com',
]);

function isAdUrl(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    if (AD_DOMAINS.has(host)) return true;
    for (const d of AD_DOMAINS) if (host.endsWith('.' + d)) return true;
    return /\/ads?\/|\/advert|\/banner|\/tracking|\/analytics/i.test(url);
  } catch { return false; }
}

// ── URL processing ────────────────────────────────────────────────────────────
function processInput(input) {
  input = input.trim();
  if (!input) return '';
  if (/^https?:\/\//i.test(input)) return input;
  if (!input.includes(' ') && input.includes('.') && input.split('.').pop().length >= 2) {
    return 'https://' + input;
  }
  const q = encodeURIComponent(input);
  return ENGINES[state.settings.searchEngine] + q;
}

function getDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return url; }
}

// ── Tab management ────────────────────────────────────────────────────────────
function createTab(url = '', isPrivate = false) {
  return {
    id: Date.now() + Math.random(),
    title: 'تبويب جديد',
    url: url || '',
    isPrivate: isPrivate || state.isPrivate,
    favicon: '',
    isHome: !url,
  };
}

function newTab(url = '') {
  const tab = createTab(url);
  state.tabs.push(tab);
  state.activeTab = state.tabs.length - 1;
  renderTabs();
  if (url) loadUrl(url);
  else showHome();
  updateTabCount();
}

function closeTab(tabId, e) {
  if (e) e.stopPropagation();
  const idx = state.tabs.findIndex(t => t.id === tabId);
  if (idx === -1) return;
  state.tabs.splice(idx, 1);
  if (state.tabs.length === 0) {
    state.tabs.push(createTab());
    state.activeTab = 0;
  } else {
    state.activeTab = Math.min(state.activeTab, state.tabs.length - 1);
  }
  renderTabs();
  updateTabCount();
  const active = state.tabs[state.activeTab];
  if (active.isHome) showHome();
  else showBrowserPage(active.url);
}

function switchTab(idx) {
  state.activeTab = idx;
  renderTabs();
  updateTabCount();
  const tab = state.tabs[idx];
  if (tab.isHome) showHome();
  else showBrowserPage(tab.url);
}

function updateActiveTab(data) {
  if (state.tabs[state.activeTab]) {
    Object.assign(state.tabs[state.activeTab], data);
    renderTabs();
  }
}

function renderTabs() {
  const list = document.getElementById('tabs-list');
  list.innerHTML = state.tabs.map((tab, i) => `
    <div class="tab-chip ${i === state.activeTab ? 'active' : ''}"
         onclick="switchTab(${i})">
      <span>${tab.isPrivate ? '🕶️' : '🌐'}</span>
      <span class="tab-title">${escHtml(tab.title)}</span>
      <button class="tab-close" onclick="closeTab(${tab.id}, event)">×</button>
    </div>
  `).join('');
}

function updateTabCount() {
  document.getElementById('tab-count').textContent = state.tabs.length;
}

// ── Navigation ────────────────────────────────────────────────────────────────
function navigate(url) {
  closeDropdown();
  url = processInput(url);
  if (!url) return;

  if (state.settings.adblock && isAdUrl(url)) {
    state.blockedCount++;
    document.getElementById('blocked-count').textContent = state.blockedCount;
    document.getElementById('blocked-count').classList.remove('hidden');
    toast('تم حجب إعلان 🛡️');
    return;
  }

  updateActiveTab({ url, title: getDomain(url), isHome: false });
  document.getElementById('url-input').value = url;
  setSecurityIcon(url);

  if (!state.isPrivate) addToHistory(url, getDomain(url));

  showBrowserPage(url, url);
}

function loadUrl(url) {
  navigate(url);
}

function homeSearch() {
  const q = document.getElementById('home-search').value.trim();
  if (!q) return;
  navigate(q);
  document.getElementById('home-search').value = '';
}

function goBack() {
  const iframe = document.getElementById('browser-iframe');
  try {
    iframe.contentWindow.history.back();
  } catch { window.history.back(); }
}
function goForward() {
  const iframe = document.getElementById('browser-iframe');
  try {
    iframe.contentWindow.history.forward();
  } catch { window.history.forward(); }
}
function goHome() {
  const iframe = document.getElementById('browser-iframe');
  iframe.src = 'about:blank';
  updateActiveTab({ url: '', title: 'تبويب جديد', isHome: true });
  showHome();
  document.getElementById('url-input').value = '';
  document.getElementById('security-icon').textContent = '🔍';
}

// ── URL Bar ───────────────────────────────────────────────────────────────────
document.getElementById('url-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const val = e.target.value.trim();
    if (val) navigate(val);
    e.target.blur();
  }
});

document.getElementById('url-input').addEventListener('focus', function () {
  this.select();
});

document.getElementById('refresh-btn').addEventListener('click', () => {
  const tab = state.tabs[state.activeTab];
  if (tab && !tab.isHome) {
    const iframe = document.getElementById('browser-iframe');
    try {
      iframe.contentWindow.location.reload();
    } catch {
      iframe.src = iframe.src;
    }
  }
});

function setSecurityIcon(url) {
  const icon = document.getElementById('security-icon');
  if (!url || url === '') { icon.textContent = '🔍'; return; }
  icon.textContent = url.startsWith('https://') ? '🔒' : '⚠️';
}

// ── Progress bar ──────────────────────────────────────────────────────────────
function startProgress() {
  const fill = document.getElementById('progress-fill');
  fill.style.width = '0%';
  fill.style.transition = 'none';
  setTimeout(() => { fill.style.transition = 'width 1.5s ease'; fill.style.width = '70%'; }, 30);
}
function finishProgress() {
  const fill = document.getElementById('progress-fill');
  fill.style.width = '100%';
  setTimeout(() => { fill.style.width = '0%'; fill.style.transition = 'none'; }, 500);
}

// ── Page display ──────────────────────────────────────────────────────────────
function showHome() {
  state.currentPage = 'home';
  document.getElementById('home-page').classList.remove('hidden');
  document.getElementById('webview-wrap').classList.add('hidden');
  hideAllInnerPages();
  updateToolbar();
  renderHomeBookmarks();
  renderHomeHistory();
}

// Domains known to always block iframe embedding (X-Frame-Options: DENY/SAMEORIGIN)
// Showing fallback instantly for these avoids a pointless 7s wait
const KNOWN_BLOCKED_DOMAINS = [
  'google.com', 'youtube.com', 'facebook.com', 'instagram.com',
  'twitter.com', 'x.com', 'linkedin.com', 'amazon.com',
  'netflix.com', 'apple.com', 'github.com', 'reddit.com',
  'gmail.com', 'mail.google.com', 'maps.google.com', 'drive.google.com',
  'tiktok.com', 'whatsapp.com', 'telegram.org', 'spotify.com',
  'paypal.com', 'chatgpt.com', 'openai.com', 'claude.ai',
];

function isKnownBlocked(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return KNOWN_BLOCKED_DOMAINS.some(d => host === d || host.endsWith('.' + d));
  } catch { return false; }
}

function showBrowserPage(url, iframeSrc) {
  state.currentPage = 'browser';
  document.getElementById('home-page').classList.add('hidden');
  document.getElementById('webview-wrap').classList.remove('hidden');
  hideAllInnerPages();

  const iframe = document.getElementById('browser-iframe');
  const loading = document.getElementById('iframe-loading');
  const fallback = document.getElementById('iframe-fallback');
  const domain = getDomain(url);
  const src = iframeSrc || url;

  // Instantly show fallback for sites we know will block embedding
  if (isKnownBlocked(url)) {
    iframe.src = 'about:blank';
    showFallback(url, domain);
    updateToolbar();
    return;
  }

  // Show loading, hide fallback
  loading.classList.remove('hidden');
  fallback.classList.add('hidden');
  iframe.style.display = 'block';
  document.getElementById('loading-domain').textContent = domain;

  // Clear previous
  iframe.src = 'about:blank';
  setTimeout(() => { iframe.src = src; }, 50);

  let settled = false;
  function onSettled() {
    if (settled) return;
    settled = true;
    loading.classList.add('hidden');
  }

  // Timeout fallback (shorter now since common cases are pre-filtered)
  const timer = setTimeout(() => {
    onSettled();
    try {
      const doc = iframe.contentDocument;
      if (!doc || doc.URL === 'about:blank') showFallback(url, domain);
    } catch {
      // Cross-origin = probably loaded fine
    }
  }, 4000);

  iframe.onload = () => {
    clearTimeout(timer);
    onSettled();
    try {
      const doc = iframe.contentDocument || iframe.contentWindow?.document;
      const iframeUrl = iframe.contentWindow?.location?.href;
      if (doc && doc.title) {
        updateActiveTab({ title: doc.title });
        renderTabs();
      }
      if (iframeUrl && iframeUrl !== 'about:blank') {
        document.getElementById('url-input').value = iframeUrl;
        setSecurityIcon(iframeUrl);
        if (!state.isPrivate) addToHistory(iframeUrl, doc?.title || domain);
      }
    } catch {
      // Cross-origin — still loaded fine
    }
    document.getElementById('url-input').value = url;
    setSecurityIcon(url);
  };

  iframe.onerror = () => {
    clearTimeout(timer);
    onSettled();
    showFallback(url, domain);
  };

  updateToolbar();
}

function showFallback(url, domain) {
  const loading = document.getElementById('iframe-loading');
  const fallback = document.getElementById('iframe-fallback');
  const iframe = document.getElementById('browser-iframe');
  loading.classList.add('hidden');
  iframe.style.display = 'none';
  fallback.classList.remove('hidden');
  document.getElementById('fallback-domain').textContent = domain;
  document.getElementById('open-external-btn').onclick = () => window.open(url, '_blank');
}

function hideAllInnerPages() {
  ['bookmarks-page', 'history-page', 'downloads-page', 'settings-page'].forEach(id => {
    document.getElementById(id).classList.add('hidden');
  });
}

function openPage(name) {
  closeDropdown();
  state.currentPage = name;
  document.getElementById('home-page').classList.add('hidden');
  document.getElementById('webview-wrap').classList.add('hidden');
  hideAllInnerPages();
  document.getElementById(name + '-page').classList.remove('hidden');

  if (name === 'bookmarks') renderBookmarksList();
  if (name === 'history') renderHistoryList();
  if (name === 'downloads') renderDownloadsList();
  if (name === 'settings') loadSettingsUI();
}

function closePage() {
  hideAllInnerPages();
  const tab = state.tabs[state.activeTab];
  if (tab && !tab.isHome) showBrowserPage(tab.url);
  else showHome();
}

function updateToolbar() {
  const isBrowser = state.currentPage === 'browser';
  document.getElementById('back-btn').disabled = !isBrowser;
  document.getElementById('fwd-btn').disabled = !isBrowser;
}

// ── Menu ──────────────────────────────────────────────────────────────────────
document.getElementById('menu-btn').addEventListener('click', toggleMenu);

function toggleMenu() {
  document.getElementById('dropdown-menu').classList.toggle('hidden');
}
function closeDropdown() {
  document.getElementById('dropdown-menu').classList.add('hidden');
}
document.addEventListener('click', e => {
  if (!e.target.closest('#menu-btn') && !e.target.closest('#dropdown-menu')) {
    closeDropdown();
  }
});

// ── Tabs Panel ────────────────────────────────────────────────────────────────
function toggleTabsPanel() {
  const panel = document.getElementById('tabs-panel');
  const isHidden = panel.classList.contains('hidden');
  panel.classList.toggle('hidden');
  if (!isHidden) return;
  renderTabsPanel();
  const title = document.getElementById('tabs-panel-title');
  title.textContent = `التبويبات (${state.tabs.length})`;
}

function renderTabsPanel() {
  const list = document.getElementById('tabs-panel-list');
  list.innerHTML = state.tabs.map((tab, i) => `
    <div class="tab-card ${i === state.activeTab ? 'active' : ''}"
         onclick="switchTab(${i}); toggleTabsPanel()">
      <div class="tab-card-header">
        <span>${tab.isPrivate ? '🕶️' : '🌐'}</span>
        <span class="tab-card-title">${escHtml(tab.title)}</span>
        <button class="tab-card-close" onclick="closeTab(${tab.id}, event)">×</button>
      </div>
      <div class="tab-card-preview">
        ${tab.isHome
          ? '<div style="text-align:center"><div style="font-size:36px">🏠</div><div style="font-size:11px;color:var(--text2);margin-top:4px">الرئيسية</div></div>'
          : `<div class="tab-preview-url">${escHtml(getDomain(tab.url))}</div>`
        }
      </div>
    </div>
  `).join('');
}

// ── Private Mode ──────────────────────────────────────────────────────────────
function togglePrivate() {
  state.isPrivate = !state.isPrivate;
  closeDropdown();
  const body = document.body;
  if (state.isPrivate) {
    body.classList.remove('theme-light', 'theme-dark');
    body.classList.add('theme-private');
    document.getElementById('private-banner').classList.remove('hidden');
    document.getElementById('home-title').textContent = 'التصفح الخاص';
    document.getElementById('home-sub').textContent = 'لن يتم حفظ السجل أو ملفات تعريف الارتباط';
    document.getElementById('private-label').textContent = 'إيقاف التصفح الخاص';
  } else {
    body.classList.remove('theme-private');
    applyTheme(state.settings.theme);
    document.getElementById('private-banner').classList.add('hidden');
    document.getElementById('home-title').textContent = 'AC Browser';
    document.getElementById('home-sub').textContent = 'تصفح سريع وآمن';
    document.getElementById('private-label').textContent = 'وضع التصفح الخاص';
  }
  toast(state.isPrivate ? 'تم تفعيل التصفح الخاص' : 'تم إيقاف التصفح الخاص');
}

// ── Bookmarks ─────────────────────────────────────────────────────────────────
function addBookmark() {
  closeDropdown();
  const tab = state.tabs[state.activeTab];
  document.getElementById('bm-title').value = tab?.title || '';
  document.getElementById('bm-url').value = tab?.url || '';
  document.getElementById('bookmark-dialog').classList.remove('hidden');
}
function closeBookmarkDialog() {
  document.getElementById('bookmark-dialog').classList.add('hidden');
}
function saveBookmark() {
  const title = document.getElementById('bm-title').value.trim();
  const url = document.getElementById('bm-url').value.trim();
  if (!url) return;
  state.bookmarks.unshift({ id: Date.now(), title: title || getDomain(url), url });
  DB.set('bookmarks', state.bookmarks);
  closeBookmarkDialog();
  toast('تمت إضافة المفضلة');
  renderHomeBookmarks();
}
function deleteBookmark(id) {
  state.bookmarks = state.bookmarks.filter(b => b.id !== id);
  DB.set('bookmarks', state.bookmarks);
  renderBookmarksList();
  renderHomeBookmarks();
  toast('تم حذف المفضلة');
}
function renderBookmarksList() {
  const list = document.getElementById('bookmarks-list');
  const empty = document.getElementById('bookmarks-empty');
  const q = document.getElementById('bookmark-search').value.toLowerCase();
  const items = state.bookmarks.filter(b =>
    b.title.toLowerCase().includes(q) || b.url.toLowerCase().includes(q)
  );
  if (!items.length) { list.innerHTML = ''; empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  list.innerHTML = items.map(b => `
    <div class="list-item" onclick="navigate('${escAttr(b.url)}')">
      <div class="list-icon">🔖</div>
      <div class="list-info">
        <div class="list-title">${escHtml(b.title)}</div>
        <div class="list-sub">${escHtml(getDomain(b.url))}</div>
      </div>
      <button class="list-action" onclick="deleteBookmark(${b.id}); event.stopPropagation()">✕</button>
    </div>
  `).join('');
}
function filterBookmarks() { renderBookmarksList(); }
function clearBookmarks() {
  if (!confirm('هل تريد مسح جميع المفضلات؟')) return;
  state.bookmarks = []; DB.set('bookmarks', []);
  renderBookmarksList(); renderHomeBookmarks();
  toast('تم مسح المفضلة');
}
function renderHomeBookmarks() {
  const sec = document.getElementById('bookmarks-home-section');
  const list = document.getElementById('bookmarks-home-list');
  const items = state.bookmarks.slice(0, 5);
  if (!items.length) { sec.style.display = 'none'; return; }
  sec.style.display = 'block';
  list.innerHTML = items.map(b => `
    <div class="home-list-item" onclick="navigate('${escAttr(b.url)}')">
      <div class="home-list-icon">🔖</div>
      <div style="flex:1;min-width:0">
        <div class="home-list-title">${escHtml(b.title)}</div>
        <div class="home-list-url">${escHtml(getDomain(b.url))}</div>
      </div>
    </div>
  `).join('');
}

// ── History ───────────────────────────────────────────────────────────────────
function addToHistory(url, title) {
  if (state.isPrivate || !url || url === 'about:blank') return;
  state.history.unshift({ id: Date.now(), url, title: title || getDomain(url), time: new Date().toISOString() });
  if (state.history.length > 500) state.history = state.history.slice(0, 500);
  DB.set('history', state.history);
}
function renderHistoryList() {
  const list = document.getElementById('history-list');
  const empty = document.getElementById('history-empty');
  const q = document.getElementById('history-search').value.toLowerCase();
  const items = state.history.filter(h =>
    h.title.toLowerCase().includes(q) || h.url.toLowerCase().includes(q)
  );
  if (!items.length) { list.innerHTML = ''; empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  list.innerHTML = items.map(h => {
    const d = new Date(h.time);
    const timeStr = d.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });
    return `
    <div class="list-item" onclick="navigate('${escAttr(h.url)}')">
      <div class="list-icon">🌐</div>
      <div class="list-info">
        <div class="list-title">${escHtml(h.title)}</div>
        <div class="list-sub">${timeStr} · ${escHtml(getDomain(h.url))}</div>
      </div>
      <button class="list-action" onclick="deleteHistory(${h.id}); event.stopPropagation()">✕</button>
    </div>`;
  }).join('');
}
function filterHistory() { renderHistoryList(); }
function deleteHistory(id) {
  state.history = state.history.filter(h => h.id !== id);
  DB.set('history', state.history); renderHistoryList(); renderHomeHistory();
}
function clearHistory() {
  if (!confirm('هل تريد مسح سجل التصفح؟')) return;
  state.history = []; DB.set('history', []);
  renderHistoryList(); renderHomeHistory();
  toast('تم مسح السجل');
}
function renderHomeHistory() {
  const sec = document.getElementById('history-home-section');
  const list = document.getElementById('history-home-list');
  const items = state.history.slice(0, 5);
  if (!items.length || state.isPrivate) { sec.style.display = 'none'; return; }
  sec.style.display = 'block';
  list.innerHTML = items.map(h => `
    <div class="home-list-item" onclick="navigate('${escAttr(h.url)}')">
      <div class="home-list-icon">🕐</div>
      <div style="flex:1;min-width:0">
        <div class="home-list-title">${escHtml(h.title)}</div>
        <div class="home-list-url">${escHtml(getDomain(h.url))}</div>
      </div>
    </div>
  `).join('');
}

// ── Downloads ─────────────────────────────────────────────────────────────────
function renderDownloadsList() {
  const list = document.getElementById('downloads-list');
  const empty = document.getElementById('downloads-empty');
  if (!state.downloads.length) { list.innerHTML = ''; empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  list.innerHTML = state.downloads.map(d => `
    <div class="list-item">
      <div class="list-icon">📄</div>
      <div class="list-info">
        <div class="list-title">${escHtml(d.name)}</div>
        <div class="list-sub">${d.size} · ${d.status}</div>
      </div>
    </div>
  `).join('');
}

// ── Settings ──────────────────────────────────────────────────────────────────
function saveSetting(key, value) {
  state.settings[key] = value;
  DB.set('settings', state.settings);
  if (key === 'theme') changeTheme(value);
}
function loadSettingsUI() {
  document.getElementById('search-engine-select').value = state.settings.searchEngine;
  document.getElementById('adblock-toggle').checked = state.settings.adblock;
  document.getElementById('theme-select').value = state.settings.theme;
}
function changeTheme(val) {
  state.settings.theme = val;
  DB.set('settings', state.settings);
  if (!state.isPrivate) applyTheme(val);
}
function applyTheme(val) {
  const body = document.body;
  body.classList.remove('theme-light', 'theme-dark');
  if (val === 'dark') body.classList.add('theme-dark');
  else if (val === 'light') body.classList.add('theme-light');
  else {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    body.classList.add(prefersDark ? 'theme-dark' : 'theme-light');
  }
}

// ── Ad block info ─────────────────────────────────────────────────────────────
function showAdBlockInfo() {
  toast(`تم حجب ${state.blockedCount} إعلان في هذه الجلسة`);
}

// ── Toast ─────────────────────────────────────────────────────────────────────
let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2500);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function escAttr(str) {
  return String(str || '').replace(/'/g, '&#39;').replace(/"/g, '&quot;');
}

// ── Init ──────────────────────────────────────────────────────────────────────
function init() {
  // Load persisted state
  state.settings = DB.get('settings', state.settings);
  state.bookmarks = DB.get('bookmarks', []);
  state.history = DB.get('history', []);

  // Apply theme
  applyTheme(state.settings.theme);
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (state.settings.theme === 'system' && !state.isPrivate) applyTheme('system');
  });

  // Initial tab
  state.tabs = [createTab()];
  renderTabs();
  updateTabCount();
  showHome();
  renderHomeBookmarks();
  renderHomeHistory();

  // Show app after splash
  setTimeout(() => {
    document.getElementById('app').classList.remove('hidden');
  }, 2000);
}

// Start when DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
