import 'package:flutter/material.dart';

extension BuildContextX on BuildContext {
  ThemeData get theme => Theme.of(this);
  ColorScheme get colors => Theme.of(this).colorScheme;
  TextTheme get textTheme => Theme.of(this).textTheme;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  double get screenWidth => MediaQuery.of(this).size.width;
  double get screenHeight => MediaQuery.of(this).size.height;
  EdgeInsets get padding => MediaQuery.of(this).padding;
}

extension StringX on String {
  /// Check if string is a valid URL
  bool get isUrl {
    if (startsWith('http://') || startsWith('https://')) return true;
    if (!contains(' ') && contains('.')) {
      final parts = split('.');
      if (parts.length >= 2 && parts.last.length >= 2) return true;
    }
    return false;
  }

  /// Ensure string has https:// prefix
  String get withHttps {
    if (startsWith('http://') || startsWith('https://')) return this;
    return 'https://$this';
  }

  /// Extract domain from URL
  String get domain {
    try {
      final uri = Uri.parse(this);
      return uri.host.replaceFirst(RegExp(r'^www\.'), '');
    } catch (_) {
      return this;
    }
  }

  /// Truncate string with ellipsis
  String truncate(int maxLength) {
    if (length <= maxLength) return this;
    return '${substring(0, maxLength)}...';
  }
}

extension DateTimeX on DateTime {
  bool get isToday {
    final now = DateTime.now();
    return year == now.year && month == now.month && day == now.day;
  }

  bool get isYesterday {
    final yesterday = DateTime.now().subtract(const Duration(days: 1));
    return year == yesterday.year &&
        month == yesterday.month &&
        day == yesterday.day;
  }

  String get relativeLabel {
    if (isToday) return 'Today';
    if (isYesterday) return 'Yesterday';
    return '$day/${month.toString().padLeft(2, '0')}/$year';
  }
}
