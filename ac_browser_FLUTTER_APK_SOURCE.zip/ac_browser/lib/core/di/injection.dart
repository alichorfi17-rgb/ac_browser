import 'package:get_it/get_it.dart';
import 'package:dio/dio.dart';

import '../../database/database_helper.dart';
import '../../services/ad_block_service.dart';
import '../../services/download_service.dart';
import '../../services/bookmark_service.dart';
import '../../services/history_service.dart';
import '../../services/settings_service.dart';
import '../../services/security_service.dart';

final GetIt getIt = GetIt.instance;

Future<void> setupInjection() async {
  // ─── Core ───────────────────────────────────────────────────────────────────
  getIt.registerSingletonAsync<DatabaseHelper>(() async {
    final db = DatabaseHelper.instance;
    await db.database; // Ensure DB is initialized
    return db;
  });

  await getIt.isReady<DatabaseHelper>();

  // ─── Networking ────────────────────────────────────────────────────────────
  getIt.registerLazySingleton<Dio>(() {
    final dio = Dio(
      BaseOptions(
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
        headers: {
          'User-Agent': 'ACBrowser/1.0',
        },
      ),
    );
    dio.interceptors.add(LogInterceptor(
      requestBody: false,
      responseBody: false,
    ));
    return dio;
  });

  // ─── Services ──────────────────────────────────────────────────────────────
  getIt.registerLazySingleton<SettingsService>(
    () => SettingsService(getIt<DatabaseHelper>()),
  );

  getIt.registerLazySingleton<BookmarkService>(
    () => BookmarkService(getIt<DatabaseHelper>()),
  );

  getIt.registerLazySingleton<HistoryService>(
    () => HistoryService(getIt<DatabaseHelper>()),
  );

  getIt.registerLazySingleton<AdBlockService>(
    () => AdBlockService(
      getIt<DatabaseHelper>(),
      getIt<Dio>(),
    ),
  );

  getIt.registerLazySingleton<DownloadService>(
    () => DownloadService(getIt<DatabaseHelper>()),
  );

  getIt.registerLazySingleton<SecurityService>(
    () => SecurityService(),
  );

  // Initialize ad block rules if needed
  await getIt<AdBlockService>().initialize();
}
