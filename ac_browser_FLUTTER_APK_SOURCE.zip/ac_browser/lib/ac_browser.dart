// Core
export 'core/constants/app_constants.dart';
export 'core/theme/app_theme.dart';
export 'core/errors/failures.dart';
export 'core/utils/url_utils.dart';
export 'core/utils/extensions.dart';
export 'core/widgets/empty_state.dart';
export 'core/widgets/shimmer_loading.dart';
export 'core/di/injection.dart';
export 'core/router/app_router.dart';

// Database
export 'database/database_helper.dart';

// Services
export 'services/ad_block_service.dart';
export 'services/bookmark_service.dart';
export 'services/connectivity_service.dart';
export 'services/download_service.dart';
export 'services/history_service.dart';
export 'services/screenshot_service.dart';
export 'services/security_service.dart';
export 'services/settings_service.dart';
export 'services/app_info_service.dart';

// Browser Feature
export 'features/browser/domain/entities/browser_tab.dart';
export 'features/browser/domain/usecases/browser_usecases.dart';
export 'features/browser/data/models/browser_models.dart';
export 'features/browser/presentation/providers/browser_provider.dart';
export 'features/browser/presentation/screens/browser_screen.dart';
export 'features/browser/presentation/screens/reading_mode_screen.dart';
export 'features/browser/presentation/screens/translator_screen.dart';
export 'features/browser/presentation/screens/pdf_viewer_screen.dart';
export 'features/browser/presentation/widgets/address_bar.dart';
export 'features/browser/presentation/widgets/browser_toolbar.dart';
export 'features/browser/presentation/widgets/browser_webview.dart';
export 'features/browser/presentation/widgets/home_page.dart';
export 'features/browser/presentation/widgets/tabs_overview.dart';
export 'features/browser/presentation/widgets/offline_page.dart';
export 'features/browser/presentation/widgets/security_warning_dialog.dart';
export 'features/browser/presentation/widgets/private_mode_banner.dart';
export 'features/browser/presentation/widgets/browser_context_menu.dart';

// Bookmarks Feature
export 'features/bookmarks/domain/entities/bookmark_entity.dart';
export 'features/bookmarks/domain/repositories/bookmark_repository.dart';
export 'features/bookmarks/domain/usecases/bookmark_usecases.dart';
export 'features/bookmarks/data/datasources/bookmarks_datasource.dart';
export 'features/bookmarks/data/repositories/bookmark_repository_impl.dart';
export 'features/bookmarks/presentation/providers/bookmarks_provider.dart';
export 'features/bookmarks/presentation/screens/bookmarks_screen.dart';
export 'features/bookmarks/presentation/widgets/add_bookmark_dialog.dart';

// History Feature
export 'features/history/domain/entities/history_entity.dart';
export 'features/history/domain/repositories/history_repository.dart';
export 'features/history/domain/usecases/history_usecases.dart';
export 'features/history/data/datasources/history_datasource.dart';
export 'features/history/data/repositories/history_repository_impl.dart';
export 'features/history/presentation/providers/history_provider.dart';
export 'features/history/presentation/screens/history_screen.dart';

// Downloads Feature
export 'features/downloads/domain/entities/download_entity.dart';
export 'features/downloads/data/datasources/downloads_datasource.dart';
export 'features/downloads/presentation/providers/downloads_provider.dart';
export 'features/downloads/presentation/screens/downloads_screen.dart';

// Settings Feature
export 'features/settings/domain/entities/settings_entity.dart';
export 'features/settings/domain/usecases/settings_usecases.dart';
export 'features/settings/data/datasources/settings_datasource.dart';
export 'features/settings/presentation/providers/settings_provider.dart';
export 'features/settings/presentation/screens/settings_screen.dart';
