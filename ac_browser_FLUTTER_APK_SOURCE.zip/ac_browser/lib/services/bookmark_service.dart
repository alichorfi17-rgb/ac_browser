import '../database/database_helper.dart';

class Bookmark {
  final int? id;
  final String title;
  final String url;
  final String? favicon;
  final DateTime createdAt;

  Bookmark({
    this.id,
    required this.title,
    required this.url,
    this.favicon,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  factory Bookmark.fromMap(Map<String, dynamic> map) {
    return Bookmark(
      id: map['id'] as int?,
      title: map['title'] as String,
      url: map['url'] as String,
      favicon: map['favicon'] as String?,
      createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'url': url,
      if (favicon != null) 'favicon': favicon,
      'created_at': createdAt.toIso8601String(),
    };
  }
}

class BookmarkService {
  final DatabaseHelper _db;

  BookmarkService(this._db);

  Future<List<Bookmark>> getAllBookmarks() async {
    final maps = await _db.getAllBookmarks();
    return maps.map((m) => Bookmark.fromMap(m)).toList();
  }

  Future<List<Bookmark>> searchBookmarks(String query) async {
    final maps = await _db.searchBookmarks(query);
    return maps.map((m) => Bookmark.fromMap(m)).toList();
  }

  Future<bool> isBookmarked(String url) => _db.isBookmarked(url);

  Future<Bookmark> addBookmark({
    required String title,
    required String url,
    String? favicon,
  }) async {
    final bookmark = Bookmark(
      title: title,
      url: url,
      favicon: favicon,
    );
    final id = await _db.insertBookmark(bookmark.toMap());
    return Bookmark(
      id: id,
      title: title,
      url: url,
      favicon: favicon,
    );
  }

  Future<void> removeBookmark(int id) => _db.deleteBookmark(id);

  Future<void> updateBookmark(
      int id, String title, String url, String? favicon) async {
    await _db.updateBookmark(id, {
      'title': title,
      'url': url,
      if (favicon != null) 'favicon': favicon,
    });
  }
}
