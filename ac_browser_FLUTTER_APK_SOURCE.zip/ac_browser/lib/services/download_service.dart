import '../database/database_helper.dart';

enum DownloadStatus { pending, downloading, completed, failed, paused, cancelled }

class DownloadItem {
  final int? id;
  final String fileName;
  final String filePath;
  final String url;
  final int size;
  final String? mimeType;
  DownloadStatus status;
  double progress;
  final DateTime downloadDate;

  DownloadItem({
    this.id,
    required this.fileName,
    required this.filePath,
    required this.url,
    this.size = 0,
    this.mimeType,
    this.status = DownloadStatus.pending,
    this.progress = 0.0,
    DateTime? downloadDate,
  }) : downloadDate = downloadDate ?? DateTime.now();

  factory DownloadItem.fromMap(Map<String, dynamic> map) {
    return DownloadItem(
      id: map['id'] as int?,
      fileName: map['file_name'] as String,
      filePath: map['file_path'] as String,
      url: map['url'] as String,
      size: (map['size'] as int?) ?? 0,
      mimeType: map['mime_type'] as String?,
      status: _parseStatus(map['status'] as String? ?? 'pending'),
      progress: (map['progress'] as num?)?.toDouble() ?? 0.0,
      downloadDate:
          DateTime.tryParse(map['download_date'] as String? ?? '') ??
              DateTime.now(),
    );
  }

  static DownloadStatus _parseStatus(String s) {
    switch (s) {
      case 'downloading':
        return DownloadStatus.downloading;
      case 'completed':
        return DownloadStatus.completed;
      case 'failed':
        return DownloadStatus.failed;
      case 'paused':
        return DownloadStatus.paused;
      case 'cancelled':
        return DownloadStatus.cancelled;
      default:
        return DownloadStatus.pending;
    }
  }

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'file_name': fileName,
        'file_path': filePath,
        'url': url,
        'size': size,
        if (mimeType != null) 'mime_type': mimeType,
        'status': status.name,
        'progress': progress,
        'download_date': downloadDate.toIso8601String(),
      };

  String get formattedSize {
    if (size <= 0) return 'Unknown size';
    if (size < 1024) return '$size B';
    if (size < 1024 * 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    if (size < 1024 * 1024 * 1024) {
      return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(size / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}

class DownloadService {
  final DatabaseHelper _db;

  DownloadService(this._db);

  Future<List<DownloadItem>> getAllDownloads() async {
    final maps = await _db.getAllDownloads();
    return maps.map((m) => DownloadItem.fromMap(m)).toList();
  }

  Future<DownloadItem> startDownload({
    required String url,
    required String fileName,
    required String filePath,
    String? mimeType,
  }) async {
    final item = DownloadItem(
      fileName: fileName,
      filePath: filePath,
      url: url,
      mimeType: mimeType,
      status: DownloadStatus.pending,
    );
    final id = await _db.insertDownload(item.toMap());
    return DownloadItem(
      id: id,
      fileName: fileName,
      filePath: filePath,
      url: url,
      mimeType: mimeType,
    );
  }

  Future<void> updateProgress(int id, double progress) async {
    await _db.updateDownload(id, {
      'progress': progress,
      'status': DownloadStatus.downloading.name,
    });
  }

  Future<void> markCompleted(int id, int fileSize) async {
    await _db.updateDownload(id, {
      'status': DownloadStatus.completed.name,
      'progress': 1.0,
      'size': fileSize,
    });
  }

  Future<void> markFailed(int id) async {
    await _db.updateDownload(id, {'status': DownloadStatus.failed.name});
  }

  Future<void> deleteDownload(int id) => _db.deleteDownload(id);
}
