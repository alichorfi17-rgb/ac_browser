/// Service handling URL security checks and safe browsing
class SecurityService {
  // Known malicious domains (in production, fetch from Google Safe Browsing API)
  static const Set<String> _maliciousDomains = {
    'malware.testing.google.test',
    'phishing.test',
  };

  /// Check if URL uses HTTPS
  bool isSecureUrl(String url) {
    try {
      final uri = Uri.parse(url);
      return uri.scheme == 'https';
    } catch (e) {
      return false;
    }
  }

  /// Check if domain is potentially malicious
  bool isMaliciousDomain(String url) {
    try {
      final uri = Uri.parse(url);
      return _maliciousDomains.contains(uri.host.toLowerCase());
    } catch (e) {
      return false;
    }
  }

  /// Get security level for a URL
  SecurityLevel getSecurityLevel(String url) {
    if (isMaliciousDomain(url)) return SecurityLevel.dangerous;
    if (isSecureUrl(url)) return SecurityLevel.secure;
    if (url.startsWith('http://')) return SecurityLevel.insecure;
    return SecurityLevel.neutral;
  }

  /// Build search URL for a given engine and query
  String buildSearchUrl(String query, String engine) {
    final encodedQuery = Uri.encodeComponent(query);
    switch (engine) {
      case 'bing':
        return 'https://www.bing.com/search?q=$encodedQuery';
      case 'duckduckgo':
        return 'https://duckduckgo.com/?q=$encodedQuery';
      default:
        return 'https://www.google.com/search?q=$encodedQuery';
    }
  }

  /// Determines whether input is a URL or search query
  String processInput(String input, String searchEngine) {
    final trimmed = input.trim();
    if (trimmed.isEmpty) return 'about:blank';

    // Check if it's already a valid URL
    if (_isValidUrl(trimmed)) {
      if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
        return 'https://$trimmed';
      }
      return trimmed;
    }

    // Treat as search query
    return buildSearchUrl(trimmed, searchEngine);
  }

  bool _isValidUrl(String input) {
    // Has protocol
    if (input.startsWith('http://') || input.startsWith('https://')) {
      return true;
    }
    // Looks like domain (contains dot, no spaces)
    if (!input.contains(' ') && input.contains('.')) {
      final parts = input.split('.');
      if (parts.length >= 2 && parts.last.length >= 2) {
        return true;
      }
    }
    // localhost or IP
    if (input == 'localhost' || _isIpAddress(input)) return true;
    return false;
  }

  bool _isIpAddress(String input) {
    final parts = input.split('.');
    if (parts.length != 4) return false;
    return parts.every((p) {
      final n = int.tryParse(p);
      return n != null && n >= 0 && n <= 255;
    });
  }
}

enum SecurityLevel {
  secure,
  insecure,
  dangerous,
  neutral,
}
