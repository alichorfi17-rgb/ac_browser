import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ConnectivityService {
  final Connectivity _connectivity = Connectivity();

  Stream<bool> get onConnectivityChanged =>
      _connectivity.onConnectivityChanged.map(
        (result) => result != ConnectivityResult.none,
      );

  Future<bool> get isConnected async {
    final result = await _connectivity.checkConnectivity();
    return result != ConnectivityResult.none;
  }
}

final connectivityProvider = StreamProvider<bool>((ref) {
  final service = ConnectivityService();
  return service.onConnectivityChanged;
});

final isConnectedProvider = FutureProvider<bool>((ref) {
  return ConnectivityService().isConnected;
});
