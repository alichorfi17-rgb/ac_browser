import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../core/constants/app_constants.dart';

/// Singleton database helper managing all SQLite operations
class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  Database? _database;

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, AppConstants.dbName);

    return await openDatabase(
      path,
      version: AppConstants.dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    ''');

    await db.execute('''
      CREATE TABLE bookmarks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        url TEXT NOT NULL,
        favicon TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(url)
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_bookmarks_url ON bookmarks(url)
    ''');

    await db.execute('''
      CREATE TABLE history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        url TEXT NOT NULL,
        visit_time TEXT NOT NULL DEFAULT (datetime('now'))
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_history_url ON history(url)
    ''');
    await db.execute('''
      CREATE INDEX idx_history_visit_time ON history(visit_time DESC)
    ''');

    await db.execute('''
      CREATE TABLE downloads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        url TEXT NOT NULL,
        size INTEGER DEFAULT 0,
        mime_type TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        progress REAL DEFAULT 0.0,
        download_date TEXT NOT NULL DEFAULT (datetime('now'))
      )
    ''');

    await db.execute('''
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT NOT NULL UNIQUE,
        value TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE adblock_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pattern TEXT NOT NULL,
        list_name TEXT NOT NULL,
        rule_type TEXT NOT NULL DEFAULT 'block',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE(pattern, list_name)
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_adblock_pattern ON adblock_rules(pattern)
    ''');

    // Insert default settings
    await _insertDefaultSettings(db);
  }

  Future<void> _insertDefaultSettings(Database db) async {
    final defaults = {
      'theme': 'system',
      'search_engine': 'google',
      'adblock_enabled': 'true',
      'homepage_type': 'default',
      'private_mode': 'false',
      'font_size': '16',
      'javascript_enabled': 'true',
      'cookies_enabled': 'true',
      'save_passwords': 'false',
      'safe_browsing': 'true',
    };

    for (final entry in defaults.entries) {
      await db.insert('settings', {
        'key': entry.key,
        'value': entry.value,
      });
    }
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Handle future migrations here
  }

  // ─── Settings ──────────────────────────────────────────────────────────────

  Future<String?> getSetting(String key) async {
    final db = await database;
    final result = await db.query(
      'settings',
      columns: ['value'],
      where: 'key = ?',
      whereArgs: [key],
    );
    if (result.isEmpty) return null;
    return result.first['value'] as String?;
  }

  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert(
      'settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ─── Bookmarks ─────────────────────────────────────────────────────────────

  Future<int> insertBookmark(Map<String, dynamic> bookmark) async {
    final db = await database;
    return await db.insert(
      'bookmarks',
      bookmark,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllBookmarks() async {
    final db = await database;
    return await db.query('bookmarks', orderBy: 'created_at DESC');
  }

  Future<List<Map<String, dynamic>>> searchBookmarks(String query) async {
    final db = await database;
    return await db.query(
      'bookmarks',
      where: 'title LIKE ? OR url LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
      orderBy: 'created_at DESC',
    );
  }

  Future<bool> isBookmarked(String url) async {
    final db = await database;
    final result = await db.query(
      'bookmarks',
      columns: ['id'],
      where: 'url = ?',
      whereArgs: [url],
    );
    return result.isNotEmpty;
  }

  Future<int> deleteBookmark(int id) async {
    final db = await database;
    return await db.delete('bookmarks', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> updateBookmark(int id, Map<String, dynamic> data) async {
    final db = await database;
    return await db.update('bookmarks', data, where: 'id = ?', whereArgs: [id]);
  }

  // ─── History ───────────────────────────────────────────────────────────────

  Future<int> insertHistory(Map<String, dynamic> history) async {
    final db = await database;
    return await db.insert('history', history);
  }

  Future<List<Map<String, dynamic>>> getHistory({int limit = 100}) async {
    final db = await database;
    return await db.query(
      'history',
      orderBy: 'visit_time DESC',
      limit: limit,
    );
  }

  Future<List<Map<String, dynamic>>> searchHistory(String query) async {
    final db = await database;
    return await db.query(
      'history',
      where: 'title LIKE ? OR url LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
      orderBy: 'visit_time DESC',
      limit: 100,
    );
  }

  Future<int> deleteHistoryItem(int id) async {
    final db = await database;
    return await db.delete('history', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> clearAllHistory() async {
    final db = await database;
    return await db.delete('history');
  }

  // ─── Downloads ─────────────────────────────────────────────────────────────

  Future<int> insertDownload(Map<String, dynamic> download) async {
    final db = await database;
    return await db.insert('downloads', download);
  }

  Future<List<Map<String, dynamic>>> getAllDownloads() async {
    final db = await database;
    return await db.query('downloads', orderBy: 'download_date DESC');
  }

  Future<int> updateDownload(int id, Map<String, dynamic> data) async {
    final db = await database;
    return await db.update('downloads', data, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteDownload(int id) async {
    final db = await database;
    return await db.delete('downloads', where: 'id = ?', whereArgs: [id]);
  }

  // ─── Ad Block ──────────────────────────────────────────────────────────────

  Future<void> insertAdBlockRules(List<Map<String, dynamic>> rules) async {
    final db = await database;
    final batch = db.batch();
    for (final rule in rules) {
      batch.insert(
        'adblock_rules',
        rule,
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<List<String>> getAdBlockPatterns() async {
    final db = await database;
    final result = await db.query('adblock_rules', columns: ['pattern']);
    return result.map((r) => r['pattern'] as String).toList();
  }

  Future<int> getAdBlockRulesCount() async {
    final db = await database;
    final result =
        await db.rawQuery('SELECT COUNT(*) as count FROM adblock_rules');
    return (result.first['count'] as int?) ?? 0;
  }

  Future<void> clearAdBlockRules() async {
    final db = await database;
    await db.delete('adblock_rules');
  }

  // ─── Cleanup ───────────────────────────────────────────────────────────────

  Future<void> close() async {
    final db = _database;
    if (db != null) {
      await db.close();
      _database = null;
    }
  }
}
