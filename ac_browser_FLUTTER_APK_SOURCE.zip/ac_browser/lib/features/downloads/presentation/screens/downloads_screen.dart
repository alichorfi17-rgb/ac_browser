import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/download_service.dart';

final downloadsProvider =
    FutureProvider.autoDispose<List<DownloadItem>>((ref) async {
  return getIt<DownloadService>().getAllDownloads();
});

class DownloadsScreen extends ConsumerWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final downloadsAsync = ref.watch(downloadsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Downloads',
            style: TextStyle(fontWeight: FontWeight.w600)),
      ),
      body: downloadsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (downloads) {
          if (downloads.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.download_outlined,
                      size: 64, color: Colors.grey[300]),
                  const SizedBox(height: 16),
                  Text(
                    'No downloads yet',
                    style: TextStyle(color: Colors.grey[500], fontSize: 16),
                  ),
                ],
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: downloads.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final d = downloads[i];
              return _DownloadCard(
                item: d,
                onDelete: () async {
                  await getIt<DownloadService>().deleteDownload(d.id!);
                  ref.invalidate(downloadsProvider);
                },
              );
            },
          );
        },
      ),
    );
  }
}

class _DownloadCard extends StatelessWidget {
  final DownloadItem item;
  final VoidCallback onDelete;

  const _DownloadCard({required this.item, required this.onDelete});

  IconData get _icon {
    final mime = item.mimeType ?? '';
    if (mime.contains('pdf')) return Icons.picture_as_pdf_rounded;
    if (mime.contains('image')) return Icons.image_rounded;
    if (mime.contains('video')) return Icons.video_file_rounded;
    if (mime.contains('audio')) return Icons.audio_file_rounded;
    return Icons.insert_drive_file_rounded;
  }

  Color get _iconColor {
    final mime = item.mimeType ?? '';
    if (mime.contains('pdf')) return Colors.red;
    if (mime.contains('image')) return Colors.purple;
    if (mime.contains('video')) return Colors.orange;
    return Colors.blue;
  }

  Color get _statusColor {
    switch (item.status) {
      case DownloadStatus.completed:
        return const Color(0xFF30D158);
      case DownloadStatus.failed:
        return const Color(0xFFFF453A);
      case DownloadStatus.downloading:
        return const Color(0xFF0A84FF);
      default:
        return Colors.grey;
    }
  }

  String get _statusLabel {
    switch (item.status) {
      case DownloadStatus.completed:
        return 'Completed';
      case DownloadStatus.failed:
        return 'Failed';
      case DownloadStatus.downloading:
        return '${(item.progress * 100).toInt()}%';
      case DownloadStatus.paused:
        return 'Paused';
      case DownloadStatus.cancelled:
        return 'Cancelled';
      default:
        return 'Pending';
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateStr =
        DateFormat('MMM d, yyyy').format(item.downloadDate);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          // File icon
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: _iconColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(_icon, color: _iconColor, size: 22),
          ),
          const SizedBox(width: 12),

          // File info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.fileName,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w500),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      item.formattedSize,
                      style: const TextStyle(
                          fontSize: 12, color: Colors.grey),
                    ),
                    const SizedBox(width: 8),
                    Text('·',
                        style: TextStyle(color: Colors.grey[400])),
                    const SizedBox(width: 8),
                    Text(
                      dateStr,
                      style: const TextStyle(
                          fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
                if (item.status == DownloadStatus.downloading) ...[
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: item.progress,
                    minHeight: 3,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),

          // Status + actions
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: _statusColor,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              GestureDetector(
                onTap: onDelete,
                child: Icon(Icons.delete_outline_rounded,
                    size: 18, color: Colors.grey[400]),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
