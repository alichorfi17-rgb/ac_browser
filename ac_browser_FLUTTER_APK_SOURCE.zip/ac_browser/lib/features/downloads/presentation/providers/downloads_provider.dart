import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/download_service.dart';

class DownloadsNotifier extends StateNotifier<List<DownloadItem>> {
  final DownloadService _service;

  DownloadsNotifier(this._service) : super([]) {
    load();
  }

  Future<void> load() async {
    final items = await _service.getAllDownloads();
    state = items;
  }

  Future<void> delete(int id) async {
    await _service.deleteDownload(id);
    await load();
  }
}

final downloadsNotifierProvider =
    StateNotifierProvider<DownloadsNotifier, List<DownloadItem>>((ref) {
  return DownloadsNotifier(getIt<DownloadService>());
});
