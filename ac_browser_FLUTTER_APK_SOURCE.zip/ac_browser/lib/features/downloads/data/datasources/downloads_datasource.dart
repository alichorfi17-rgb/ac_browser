import '../../../../database/database_helper.dart';
import '../../domain/entities/download_entity.dart';

class DownloadsDataSource {
  final DatabaseHelper _db;

  DownloadsDataSource(this._db);

  Future<List<DownloadEntity>> getAll() async {
    final maps = await _db.getAllDownloads();
    return maps.map(_fromMap).toList();
  }

  Future<int> insert({
    required String fileName,
    required String filePath,
    required String url,
    String? mimeType,
  }) async {
    return await _db.insertDownload({
      'file_name': fileName,
      'file_path': filePath,
      'url': url,
      if (mimeType != null) 'mime_type': mimeType,
      'status': 'pending',
      'progress': 0.0,
      'download_date': DateTime.now().toIso8601String(),
    });
  }

  Future<void> updateProgress(int id, double progress) async {
    await _db.updateDownload(id, {
      'progress': progress,
      'status': 'downloading',
    });
  }

  Future<void> markCompleted(int id, int size) async {
    await _db.updateDownload(id, {
      'status': 'completed',
      'progress': 1.0,
      'size': size,
    });
  }

  Future<void> markFailed(int id) async {
    await _db.updateDownload(id, {'status': 'failed'});
  }

  Future<void> delete(int id) => _db.deleteDownload(id);

  DownloadEntity _fromMap(Map<String, dynamic> m) => DownloadEntity(
        id: m['id'] as int?,
        fileName: m['file_name'] as String,
        filePath: m['file_path'] as String,
        url: m['url'] as String,
        size: (m['size'] as int?) ?? 0,
        mimeType: m['mime_type'] as String?,
        status: m['status'] as String? ?? 'pending',
        progress: (m['progress'] as num?)?.toDouble() ?? 0.0,
        downloadDate:
            DateTime.tryParse(m['download_date'] as String? ?? '') ??
                DateTime.now(),
      );
}
