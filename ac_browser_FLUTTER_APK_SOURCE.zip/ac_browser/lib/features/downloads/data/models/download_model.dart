import '../../domain/entities/download_entity.dart';

/// Data model for download stored in SQLite
class DownloadDataModel {
  final int? id;
  final String fileName;
  final String filePath;
  final String url;
  final int size;
  final String? mimeType;
  final String status;
  final double progress;
  final String downloadDate;

  const DownloadDataModel({
    this.id,
    required this.fileName,
    required this.filePath,
    required this.url,
    this.size = 0,
    this.mimeType,
    this.status = 'pending',
    this.progress = 0.0,
    required this.downloadDate,
  });

  factory DownloadDataModel.fromMap(Map<String, dynamic> map) =>
      DownloadDataModel(
        id: map['id'] as int?,
        fileName: map['file_name'] as String,
        filePath: map['file_path'] as String,
        url: map['url'] as String,
        size: (map['size'] as int?) ?? 0,
        mimeType: map['mime_type'] as String?,
        status: map['status'] as String? ?? 'pending',
        progress: (map['progress'] as num?)?.toDouble() ?? 0.0,
        downloadDate: map['download_date'] as String? ??
            DateTime.now().toIso8601String(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'file_name': fileName,
        'file_path': filePath,
        'url': url,
        'size': size,
        if (mimeType != null) 'mime_type': mimeType,
        'status': status,
        'progress': progress,
        'download_date': downloadDate,
      };

  DownloadEntity toEntity() => DownloadEntity(
        id: id,
        fileName: fileName,
        filePath: filePath,
        url: url,
        size: size,
        mimeType: mimeType,
        status: status,
        progress: progress,
        downloadDate:
            DateTime.tryParse(downloadDate) ?? DateTime.now(),
      );
}
