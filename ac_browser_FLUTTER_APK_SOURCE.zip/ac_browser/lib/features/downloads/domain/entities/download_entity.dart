/// Domain entity for a download item
class DownloadEntity {
  final int? id;
  final String fileName;
  final String filePath;
  final String url;
  final int size;
  final String? mimeType;
  final String status;
  final double progress;
  final DateTime downloadDate;

  const DownloadEntity({
    this.id,
    required this.fileName,
    required this.filePath,
    required this.url,
    this.size = 0,
    this.mimeType,
    this.status = 'pending',
    this.progress = 0.0,
    required this.downloadDate,
  });

  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';
  bool get isDownloading => status == 'downloading';

  String get formattedSize {
    if (size <= 0) return 'Unknown';
    if (size < 1024) return '$size B';
    if (size < 1024 * 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}
