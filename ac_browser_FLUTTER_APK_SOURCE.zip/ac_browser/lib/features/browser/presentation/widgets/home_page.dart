import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/di/injection.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../services/security_service.dart';
import '../../../../services/bookmark_service.dart';
import '../../../../services/history_service.dart';
import '../providers/browser_provider.dart';
import '../../../../features/settings/presentation/providers/settings_provider.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  final _searchController = TextEditingController();
  final _securityService = getIt<SecurityService>();
  final _bookmarkService = getIt<BookmarkService>();
  final _historyService = getIt<HistoryService>();
  List<Bookmark> _bookmarks = [];
  List<HistoryItem> _recentHistory = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final bookmarks = await _bookmarkService.getAllBookmarks();
    final history = await _historyService.getHistory(limit: 6);
    if (mounted) {
      setState(() {
        _bookmarks = bookmarks.take(6).toList();
        _recentHistory = history;
      });
    }
  }

  void _search(String input) {
    if (input.trim().isEmpty) return;
    final settings = ref.read(settingsProvider);
    final url = _securityService.processInput(input, settings.searchEngine);
    _navigate(url);
  }

  void _navigate(String url) {
    final notifier = ref.read(browserProvider.notifier);
    final activeTab = ref.read(browserProvider).activeTab;
    if (activeTab?.controller != null) {
      activeTab!.controller!
          .loadUrl(urlRequest: URLRequest(url: WebUri(url)));
    } else {
      notifier.addNewTab(url: url);
    }
    notifier.setActiveTabUrl(url);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPrivate = ref.watch(isPrivateModeProvider);
    final ext = theme.extension<ACBrowserThemeExtension>();

    final bgColor = isPrivate
        ? const Color(0xFF1A0A2E)
        : theme.scaffoldBackgroundColor;

    return Container(
      color: bgColor,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 32),

            // Logo
            _ACLogo(isPrivate: isPrivate),

            const SizedBox(height: 8),

            Text(
              isPrivate ? 'Private Browsing' : 'AC Browser',
              style: theme.textTheme.titleMedium?.copyWith(
                color: isPrivate ? Colors.white54 : ext?.textSecondary,
                letterSpacing: 0.5,
              ),
            ),

            const SizedBox(height: 28),

            // Search box
            _SearchBox(
              controller: _searchController,
              isPrivate: isPrivate,
              onSearch: _search,
            ),

            const SizedBox(height: 32),

            // Quick access sites
            _SectionTitle(
              title: 'Quick Access',
              isPrivate: isPrivate,
            ),
            const SizedBox(height: 12),
            _QuickAccessGrid(
              onTap: _navigate,
              isPrivate: isPrivate,
            ),

            // Recent bookmarks
            if (_bookmarks.isNotEmpty) ...[
              const SizedBox(height: 28),
              _SectionTitle(title: 'Bookmarks', isPrivate: isPrivate),
              const SizedBox(height: 12),
              _BookmarksList(
                bookmarks: _bookmarks,
                onTap: _navigate,
              ),
            ],

            // Recent history (skip in private mode)
            if (!isPrivate && _recentHistory.isNotEmpty) ...[
              const SizedBox(height: 28),
              _SectionTitle(title: 'Recent', isPrivate: false),
              const SizedBox(height: 12),
              _RecentHistory(
                items: _recentHistory,
                onTap: _navigate,
              ),
            ],

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

// ─── Sub-widgets ──────────────────────────────────────────────────────────────

class _ACLogo extends StatelessWidget {
  final bool isPrivate;
  const _ACLogo({required this.isPrivate});

  @override
  Widget build(BuildContext context) {
    final color = isPrivate ? const Color(0xFF9B5DE5) : const Color(0xFF0A84FF);
    return Container(
      width: 72,
      height: 72,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isPrivate
              ? [const Color(0xFF9B5DE5), const Color(0xFF6A0572)]
              : [const Color(0xFF0A84FF), const Color(0xFF0066CC)],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: const Center(
        child: Text(
          'AC',
          style: TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.w800,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}

class _SearchBox extends StatelessWidget {
  final TextEditingController controller;
  final bool isPrivate;
  final ValueChanged<String> onSearch;

  const _SearchBox({
    required this.controller,
    required this.isPrivate,
    required this.onSearch,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: isPrivate ? const Color(0xFF2D1B4E) : Colors.grey.shade100,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isPrivate
              ? const Color(0xFF9B5DE5).withOpacity(0.3)
              : Colors.transparent,
        ),
      ),
      child: Row(
        children: [
          const SizedBox(width: 14),
          Icon(
            Icons.search_rounded,
            size: 20,
            color: isPrivate ? Colors.white38 : Colors.grey,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Search or enter address',
                hintStyle: TextStyle(
                  color: isPrivate ? Colors.white38 : Colors.grey,
                  fontSize: 15,
                ),
                contentPadding: EdgeInsets.zero,
                isDense: true,
              ),
              style: TextStyle(
                color: isPrivate ? Colors.white : Colors.black87,
                fontSize: 15,
              ),
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.search,
              onSubmitted: onSearch,
            ),
          ),
          if (controller.text.isNotEmpty)
            GestureDetector(
              onTap: () => controller.clear(),
              child: Icon(Icons.close_rounded,
                  size: 16,
                  color: isPrivate ? Colors.white38 : Colors.grey),
            ),
          const SizedBox(width: 14),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final bool isPrivate;

  const _SectionTitle({required this.title, required this.isPrivate});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        title,
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: isPrivate ? Colors.white38 : Colors.grey[600],
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

class _QuickAccessGrid extends StatelessWidget {
  final ValueChanged<String> onTap;
  final bool isPrivate;

  const _QuickAccessGrid({required this.onTap, required this.isPrivate});

  @override
  Widget build(BuildContext context) {
    final sites = AppConstants.quickAccessSites;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: sites.map((site) {
        return _QuickSiteItem(
          name: site.name,
          url: site.url,
          isPrivate: isPrivate,
          onTap: () => onTap(site.url),
        );
      }).toList(),
    );
  }
}

class _QuickSiteItem extends StatelessWidget {
  final String name;
  final String url;
  final bool isPrivate;
  final VoidCallback onTap;

  const _QuickSiteItem({
    required this.name,
    required this.url,
    required this.isPrivate,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final initial = name[0].toUpperCase();
    final colors = [
      [Colors.blue.shade400, Colors.blue.shade600],
      [Colors.red.shade400, Colors.red.shade600],
      [Colors.indigo.shade400, Colors.indigo.shade600],
      [Colors.grey.shade500, Colors.grey.shade700],
      [Colors.orange.shade400, Colors.orange.shade600],
    ];
    final colorIdx = name.hashCode.abs() % colors.length;

    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: colors[colorIdx]
                    .map((c) => (c as Color))
                    .toList(),
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: colors[colorIdx][0].withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Center(
              child: Text(
                initial,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            name,
            style: TextStyle(
              fontSize: 11,
              color: isPrivate ? Colors.white60 : Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _BookmarksList extends StatelessWidget {
  final List<Bookmark> bookmarks;
  final ValueChanged<String> onTap;

  const _BookmarksList({required this.bookmarks, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: bookmarks
          .map((b) => ListTile(
                dense: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                leading: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.bookmark_rounded,
                      size: 18, color: Color(0xFF0A84FF)),
                ),
                title: Text(
                  b.title,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w500),
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: Text(
                  b.url,
                  style: const TextStyle(fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => onTap(b.url),
              ))
          .toList(),
    );
  }
}

class _RecentHistory extends StatelessWidget {
  final List<HistoryItem> items;
  final ValueChanged<String> onTap;

  const _RecentHistory({required this.items, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: items
          .map((h) => ListTile(
                dense: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                leading: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.history_rounded,
                      size: 18, color: Colors.grey),
                ),
                title: Text(
                  h.title ?? h.url,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w500),
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: Text(
                  h.url,
                  style: const TextStyle(fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => onTap(h.url),
              ))
          .toList(),
    );
  }
}
