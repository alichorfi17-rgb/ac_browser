import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/browser_provider.dart';
import '../../domain/entities/browser_tab.dart';

class TabsOverview extends ConsumerWidget {
  const TabsOverview({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final browser = ref.watch(browserProvider);
    final tabs = browser.tabs;
    final activeIndex = browser.activeTabIndex;
    final isPrivate = browser.isPrivateMode;

    final bgColor = isPrivate
        ? const Color(0xFF1A0A2E)
        : Theme.of(context).scaffoldBackgroundColor;

    final accentColor = isPrivate
        ? const Color(0xFF9B5DE5)
        : const Color(0xFF0A84FF);

    return Material(
      color: bgColor,
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 8, 8),
              child: Row(
                children: [
                  Text(
                    isPrivate ? 'Private Tabs' : 'Tabs',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${tabs.length}',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: accentColor,
                      ),
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () =>
                        ref.read(browserProvider.notifier).hideTabsOverview(),
                  ),
                ],
              ),
            ),

            // Tab grid
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(12),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: tabs.length,
                itemBuilder: (context, i) => _TabCard(
                  tab: tabs[i],
                  isActive: i == activeIndex,
                  isPrivate: isPrivate,
                  onTap: () =>
                      ref.read(browserProvider.notifier).switchToTab(i),
                  onClose: () =>
                      ref.read(browserProvider.notifier).closeTab(tabs[i].id),
                ),
              ),
            ),

            // Bottom actions
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // New tab
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () {
                        ref
                            .read(browserProvider.notifier)
                            .addNewTab(isPrivate: isPrivate);
                      },
                      icon: const Icon(Icons.add_rounded),
                      label: Text(
                          isPrivate ? 'New Private Tab' : 'New Tab'),
                      style: FilledButton.styleFrom(
                        backgroundColor: accentColor,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TabCard extends StatelessWidget {
  final BrowserTab tab;
  final bool isActive;
  final bool isPrivate;
  final VoidCallback onTap;
  final VoidCallback onClose;

  const _TabCard({
    required this.tab,
    required this.isActive,
    required this.isPrivate,
    required this.onTap,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accentColor = isPrivate
        ? const Color(0xFF9B5DE5)
        : const Color(0xFF0A84FF);
    final cardColor = isPrivate
        ? const Color(0xFF2D1B4E)
        : (theme.brightness == Brightness.dark
            ? const Color(0xFF2C2C2E)
            : Colors.white);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(14),
          border: isActive
              ? Border.all(color: accentColor, width: 2)
              : Border.all(
                  color: Colors.grey.withOpacity(0.2),
                  width: 1,
                ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            // Tab header with title and close
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  // Favicon placeholder
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Icon(
                      tab.isPrivate
                          ? Icons.visibility_off_rounded
                          : Icons.language_rounded,
                      size: 10,
                      color: accentColor,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      tab.title,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  GestureDetector(
                    onTap: onClose,
                    child: Icon(
                      Icons.close_rounded,
                      size: 16,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),

            // Preview area
            Expanded(
              child: Container(
                margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                decoration: BoxDecoration(
                  color: isPrivate
                      ? const Color(0xFF1A0A2E)
                      : Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: tab.isHomePage
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.home_rounded,
                              size: 28,
                              color: accentColor.withOpacity(0.4),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'New Tab',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey[400],
                              ),
                            ),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.language_rounded,
                              size: 28,
                              color: Colors.grey[300],
                            ),
                            const SizedBox(height: 4),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                tab.url,
                                style: TextStyle(
                                  fontSize: 9,
                                  color: Colors.grey[400],
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),

            // Loading indicator
            if (tab.isLoading)
              LinearProgressIndicator(
                value: tab.loadingProgress > 0 ? tab.loadingProgress : null,
                minHeight: 2,
                color: accentColor,
                backgroundColor: Colors.transparent,
              ),
          ],
        ),
      ),
    );
  }
}
