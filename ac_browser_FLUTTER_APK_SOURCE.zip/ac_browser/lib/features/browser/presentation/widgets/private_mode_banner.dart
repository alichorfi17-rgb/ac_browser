import 'package:flutter/material.dart';

class PrivateModeBanner extends StatelessWidget {
  const PrivateModeBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: const Color(0xFF2D1B4E),
      child: Row(
        children: [
          const Icon(
            Icons.visibility_off_rounded,
            size: 16,
            color: Color(0xFF9B5DE5),
          ),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Private Mode — history, cookies and form data won\'t be saved.',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white70,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
