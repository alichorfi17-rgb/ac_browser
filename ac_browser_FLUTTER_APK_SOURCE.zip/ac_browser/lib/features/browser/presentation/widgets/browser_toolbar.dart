import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/browser_provider.dart';
import '../../../../core/theme/app_theme.dart';

class BrowserToolbar extends ConsumerWidget {
  final bool isPrivate;

  const BrowserToolbar({super.key, this.isPrivate = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final browser = ref.watch(browserProvider);
    final tab = browser.activeTab;
    final theme = Theme.of(context);
    final ext = theme.extension<ACBrowserThemeExtension>();

    final bgColor = isPrivate
        ? const Color(0xFF2D1B4E)
        : theme.scaffoldBackgroundColor;

    final iconColor = isPrivate ? Colors.white70 : theme.iconTheme.color;
    final disabledColor = isPrivate ? Colors.white24 : Colors.grey[400];

    return Container(
      height: 54 + MediaQuery.of(context).padding.bottom,
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom),
      decoration: BoxDecoration(
        color: bgColor,
        border: Border(
          top: BorderSide(
            color: ext?.dividerColor ?? Colors.grey.shade200,
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Back
          _ToolbarButton(
            icon: Icons.arrow_back_ios_rounded,
            onTap: tab?.canGoBack == true
                ? () => ref.read(browserProvider.notifier).navigateBack()
                : null,
            color: tab?.canGoBack == true ? iconColor : disabledColor,
          ),

          // Forward
          _ToolbarButton(
            icon: Icons.arrow_forward_ios_rounded,
            onTap: tab?.canGoForward == true
                ? () => ref.read(browserProvider.notifier).navigateForward()
                : null,
            color: tab?.canGoForward == true ? iconColor : disabledColor,
          ),

          // Home
          _ToolbarButton(
            icon: Icons.home_rounded,
            onTap: () {
              ref.read(browserProvider.notifier).updateActiveTab((t) {
                t.url = 'about:blank';
                t.title = 'New Tab';
                t.isLoading = false;
                return t;
              });
            },
            color: iconColor,
          ),

          // Tabs counter
          _TabsButton(
            count: browser.tabCount,
            isPrivate: isPrivate,
            onTap: () => ref.read(browserProvider.notifier).toggleTabsOverview(),
          ),

          // Ad block counter
          _AdBlockBadge(
            count: tab?.blockedAdsCount ?? 0,
            isPrivate: isPrivate,
          ),
        ],
      ),
    );
  }
}

class _ToolbarButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final Color? color;

  const _ToolbarButton({
    required this.icon,
    this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 48,
        height: 48,
        child: Center(
          child: Icon(icon, size: 22, color: color),
        ),
      ),
    );
  }
}

class _TabsButton extends StatelessWidget {
  final int count;
  final bool isPrivate;
  final VoidCallback onTap;

  const _TabsButton({
    required this.count,
    required this.isPrivate,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = isPrivate ? const Color(0xFF9B5DE5) : Theme.of(context).colorScheme.primary;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 48,
        height: 48,
        child: Center(
          child: Container(
            width: 28,
            height: 24,
            decoration: BoxDecoration(
              border: Border.all(color: color, width: 1.8),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Center(
              child: Text(
                count > 99 ? ':D' : count.toString(),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: color,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AdBlockBadge extends StatelessWidget {
  final int count;
  final bool isPrivate;

  const _AdBlockBadge({required this.count, required this.isPrivate});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$count ads blocked on this page'),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      },
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 48,
        height: 48,
        child: Center(
          child: Stack(
            alignment: Alignment.center,
            children: [
              Icon(
                Icons.shield_rounded,
                size: 26,
                color: isPrivate
                    ? const Color(0xFF9B5DE5)
                    : const Color(0xFF30D158),
              ),
              if (count > 0)
                Positioned(
                  top: 6,
                  right: 4,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0A84FF),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      count > 99 ? '99+' : count.toString(),
                      style: const TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
