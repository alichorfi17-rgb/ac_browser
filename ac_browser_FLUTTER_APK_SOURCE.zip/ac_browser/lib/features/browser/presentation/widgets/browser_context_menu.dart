import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/bookmark_service.dart';
import '../providers/browser_provider.dart';

/// Shows context menu for long-press on links/images in browser
class BrowserContextMenu extends ConsumerWidget {
  final String? linkUrl;
  final String? imageUrl;
  final String? text;
  final VoidCallback onDismiss;

  const BrowserContextMenu({
    super.key,
    this.linkUrl,
    this.imageUrl,
    this.text,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Material(
      color: Colors.black54,
      child: GestureDetector(
        onTap: onDismiss,
        child: Align(
          alignment: Alignment.bottomCenter,
          child: GestureDetector(
            onTap: () {},
            child: Container(
              margin: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Handle
                  Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(top: 12, bottom: 4),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),

                  // URL preview
                  if (linkUrl != null)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                      child: Text(
                        linkUrl!,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade500,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                      ),
                    ),

                  if (linkUrl != null) ...[
                    _MenuItem(
                      icon: Icons.open_in_new_rounded,
                      label: 'Open in New Tab',
                      onTap: () {
                        onDismiss();
                        ref
                            .read(browserProvider.notifier)
                            .addNewTab(url: linkUrl!);
                      },
                    ),
                    _MenuItem(
                      icon: Icons.copy_rounded,
                      label: 'Copy Link',
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: linkUrl!));
                        onDismiss();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Link copied'),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                    ),
                    _MenuItem(
                      icon: Icons.bookmark_add_outlined,
                      label: 'Bookmark Link',
                      onTap: () async {
                        await getIt<BookmarkService>().addBookmark(
                          title: linkUrl!,
                          url: linkUrl!,
                        );
                        onDismiss();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Bookmark added'),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                    ),
                  ],

                  if (imageUrl != null)
                    _MenuItem(
                      icon: Icons.download_outlined,
                      label: 'Download Image',
                      onTap: () {
                        onDismiss();
                        // Trigger download
                      },
                    ),

                  if (text != null)
                    _MenuItem(
                      icon: Icons.copy_rounded,
                      label: 'Copy Text',
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: text!));
                        onDismiss();
                      },
                    ),

                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _MenuItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, size: 20, color: const Color(0xFF0A84FF)),
      title: Text(label, style: const TextStyle(fontSize: 15)),
      onTap: onTap,
      dense: true,
    );
  }
}
