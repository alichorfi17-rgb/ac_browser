import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/security_service.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/browser_tab.dart';
import '../providers/browser_provider.dart';
import '../../../../features/settings/presentation/providers/settings_provider.dart';

class AddressBar extends ConsumerStatefulWidget {
  final BrowserTab? tab;
  final bool isPrivate;

  const AddressBar({super.key, this.tab, this.isPrivate = false});

  @override
  ConsumerState<AddressBar> createState() => _AddressBarState();
}

class _AddressBarState extends ConsumerState<AddressBar> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  bool _isEditing = false;
  final _securityService = getIt<SecurityService>();

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      setState(() => _isEditing = _focusNode.hasFocus);
      if (_focusNode.hasFocus) {
        _controller.selection = TextSelection(
          baseOffset: 0,
          extentOffset: _controller.text.length,
        );
      }
    });
  }

  @override
  void didUpdateWidget(AddressBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!_isEditing) {
      final url = widget.tab?.url ?? '';
      if (url != 'about:blank') {
        _controller.text = url;
      } else {
        _controller.clear();
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onSubmit(String input) {
    final settings = ref.read(settingsProvider);
    final url = _securityService.processInput(input, settings.searchEngine);
    _focusNode.unfocus();
    final notifier = ref.read(browserProvider.notifier);
    final activeTab = ref.read(browserProvider).activeTab;
    if (activeTab?.controller != null) {
      activeTab!.controller!.loadUrl(urlRequest: URLRequest(url: WebUri(url)));
    } else {
      notifier.addNewTab(url: url);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ext = theme.extension<ACBrowserThemeExtension>();
    final isPrivate = widget.isPrivate;
    final tab = widget.tab;

    final securityLevel = tab != null && tab.url != 'about:blank'
        ? _securityService.getSecurityLevel(tab.url)
        : SecurityLevel.neutral;

    return Container(
      color: isPrivate ? const Color(0xFF1A0A2E) : theme.scaffoldBackgroundColor,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
          child: Row(
            children: [
              // Private mode icon
              if (isPrivate)
                Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Icon(
                    Icons.visibility_off_rounded,
                    size: 18,
                    color: const Color(0xFF9B5DE5),
                  ),
                ),

              // Address field
              Expanded(
                child: GestureDetector(
                  onTap: () => _focusNode.requestFocus(),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 44,
                    decoration: BoxDecoration(
                      color: isPrivate
                          ? const Color(0xFF2D1B4E)
                          : (ext?.addressBarColor ??
                              theme.colorScheme.surfaceVariant),
                      borderRadius: BorderRadius.circular(14),
                      border: _isEditing
                          ? Border.all(
                              color: isPrivate
                                  ? const Color(0xFF9B5DE5)
                                  : theme.colorScheme.primary,
                              width: 1.5,
                            )
                          : null,
                    ),
                    child: Row(
                      children: [
                        const SizedBox(width: 10),

                        // Security / favicon icon
                        _SecurityIcon(
                          level: securityLevel,
                          isPrivate: isPrivate,
                          favicon: tab?.favicon,
                          isHomePage: tab?.isHomePage ?? true,
                        ),

                        const SizedBox(width: 6),

                        // URL / Search text field
                        Expanded(
                          child: TextField(
                            controller: _controller,
                            focusNode: _focusNode,
                            textAlignVertical: TextAlignVertical.center,
                            style: TextStyle(
                              fontSize: 14,
                              color: isPrivate
                                  ? Colors.white
                                  : theme.colorScheme.onSurface,
                              fontWeight: FontWeight.w400,
                            ),
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Search or enter URL',
                              hintStyle: TextStyle(
                                fontSize: 14,
                                color: isPrivate
                                    ? Colors.white38
                                    : (ext?.textSecondary ?? Colors.grey),
                              ),
                              isDense: true,
                              contentPadding: EdgeInsets.zero,
                            ),
                            keyboardType: TextInputType.url,
                            textInputAction: TextInputAction.go,
                            autocorrect: false,
                            onSubmitted: _onSubmit,
                            onTap: () {
                              if (!_isEditing) {
                                _controller.selection = TextSelection(
                                  baseOffset: 0,
                                  extentOffset: _controller.text.length,
                                );
                              }
                            },
                          ),
                        ),

                        // Clear / Reload button
                        if (_isEditing && _controller.text.isNotEmpty)
                          GestureDetector(
                            onTap: () => _controller.clear(),
                            child: Icon(
                              Icons.close_rounded,
                              size: 16,
                              color: ext?.textSecondary ?? Colors.grey,
                            ),
                          )
                        else if (tab?.isLoading == true)
                          GestureDetector(
                            onTap: () =>
                                ref.read(browserProvider.notifier).stopLoading(),
                            child: Icon(
                              Icons.close_rounded,
                              size: 16,
                              color: ext?.textSecondary ?? Colors.grey,
                            ),
                          )
                        else if (tab?.hasValidUrl == true)
                          GestureDetector(
                            onTap: () =>
                                ref.read(browserProvider.notifier).reload(),
                            child: Icon(
                              Icons.refresh_rounded,
                              size: 16,
                              color: ext?.textSecondary ?? Colors.grey,
                            ),
                          ),
                        const SizedBox(width: 8),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 8),

              // Menu button
              _MenuButton(isPrivate: isPrivate),
            ],
          ),
        ),
      ),
    );
  }
}

class _SecurityIcon extends StatelessWidget {
  final SecurityLevel level;
  final bool isPrivate;
  final String? favicon;
  final bool isHomePage;

  const _SecurityIcon({
    required this.level,
    required this.isPrivate,
    this.favicon,
    this.isHomePage = false,
  });

  @override
  Widget build(BuildContext context) {
    if (isHomePage) {
      return Icon(
        Icons.search_rounded,
        size: 16,
        color: isPrivate ? Colors.white38 : Colors.grey,
      );
    }

    switch (level) {
      case SecurityLevel.secure:
        return const Icon(Icons.lock_rounded, size: 14, color: Color(0xFF30D158));
      case SecurityLevel.insecure:
        return const Icon(Icons.lock_open_rounded,
            size: 14, color: Color(0xFFFF9F0A));
      case SecurityLevel.dangerous:
        return const Icon(Icons.dangerous_rounded,
            size: 14, color: Color(0xFFFF453A));
      default:
        return Icon(Icons.globe_rounded, size: 14, color: Colors.grey[500]);
    }
  }
}

class _MenuButton extends ConsumerWidget {
  final bool isPrivate;

  const _MenuButton({required this.isPrivate});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return PopupMenuButton<String>(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      icon: Icon(
        Icons.more_vert_rounded,
        color: isPrivate ? Colors.white : Theme.of(context).iconTheme.color,
      ),
      onSelected: (value) => _handleMenu(context, ref, value),
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'bookmarks',
          child: ListTile(
            leading: Icon(Icons.bookmark_outline_rounded),
            title: Text('Bookmarks'),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'history',
          child: ListTile(
            leading: Icon(Icons.history_rounded),
            title: Text('History'),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'downloads',
          child: ListTile(
            leading: Icon(Icons.download_outlined),
            title: Text('Downloads'),
            dense: true,
          ),
        ),
        const PopupMenuDivider(),
        PopupMenuItem(
          value: 'private',
          child: ListTile(
            leading: Icon(
              isPrivate
                  ? Icons.visibility_off_rounded
                  : Icons.visibility_off_outlined,
              color: isPrivate ? const Color(0xFF9B5DE5) : null,
            ),
            title: Text(isPrivate ? 'Exit Private Mode' : 'Private Mode'),
            dense: true,
          ),
        ),
        const PopupMenuItem(
          value: 'add_bookmark',
          child: ListTile(
            leading: Icon(Icons.bookmark_add_outlined),
            title: Text('Add Bookmark'),
            dense: true,
          ),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem(
          value: 'settings',
          child: ListTile(
            leading: Icon(Icons.settings_outlined),
            title: Text('Settings'),
            dense: true,
          ),
        ),
      ],
    );
  }

  void _handleMenu(BuildContext context, WidgetRef ref, String action) {
    switch (action) {
      case 'bookmarks':
        context.push('/bookmarks');
        break;
      case 'history':
        context.push('/history');
        break;
      case 'downloads':
        context.push('/downloads');
        break;
      case 'settings':
        context.push('/settings');
        break;
      case 'private':
        ref.read(browserProvider.notifier).togglePrivateMode();
        break;
      case 'add_bookmark':
        _showAddBookmark(context, ref);
        break;
    }
  }

  void _showAddBookmark(BuildContext context, WidgetRef ref) {
    final tab = ref.read(browserProvider).activeTab;
    if (tab == null || tab.isHomePage) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Bookmarked: ${tab.title}'),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
