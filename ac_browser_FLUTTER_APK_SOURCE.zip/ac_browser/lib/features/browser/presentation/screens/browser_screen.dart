import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/browser_provider.dart';
import '../widgets/browser_webview.dart';
import '../widgets/address_bar.dart';
import '../widgets/browser_toolbar.dart';
import '../widgets/tabs_overview.dart';
import '../widgets/home_page.dart';
import '../../domain/entities/browser_tab.dart';

class BrowserScreen extends ConsumerWidget {
  const BrowserScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final browserState = ref.watch(browserProvider);
    final activeTab = browserState.activeTab;
    final isPrivate = browserState.isPrivateMode;

    return Scaffold(
      backgroundColor: isPrivate
          ? const Color(0xFF1A0A2E)
          : Theme.of(context).scaffoldBackgroundColor,
      body: Stack(
        children: [
          // WebView stack (all tabs rendered, only active is visible)
          ...browserState.tabs.asMap().entries.map((entry) {
            final index = entry.key;
            final tab = entry.value;
            return Offstage(
              offstage: index != browserState.activeTabIndex,
              child: BrowserWebView(tab: tab),
            );
          }),

          // Main layout
          Column(
            children: [
              // Address bar at top
              AddressBar(
                tab: activeTab,
                isPrivate: isPrivate,
              ),

              // Progress indicator
              if (activeTab?.isLoading == true)
                LinearProgressIndicator(
                  value: activeTab!.loadingProgress > 0
                      ? activeTab.loadingProgress
                      : null,
                  minHeight: 2,
                  backgroundColor: Colors.transparent,
                  color: isPrivate
                      ? const Color(0xFF9B5DE5)
                      : Theme.of(context).colorScheme.primary,
                ),

              // Home page shown when no URL loaded
              if (activeTab?.isHomePage == true)
                const Expanded(child: HomePage()),

              // Spacer to push toolbar to bottom when webview active
              if (activeTab?.isHomePage == false) const Spacer(),

              // Bottom toolbar
              BrowserToolbar(isPrivate: isPrivate),
            ],
          ),

          // Tabs overview overlay
          if (browserState.showTabsOverview)
            const TabsOverview(),
        ],
      ),
    );
  }
}
