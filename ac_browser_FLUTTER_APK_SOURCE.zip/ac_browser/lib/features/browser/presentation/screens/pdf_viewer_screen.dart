import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

/// Built-in PDF viewer using Google Docs viewer as fallback
class PdfViewerScreen extends StatefulWidget {
  final String url;
  final String filename;

  const PdfViewerScreen({
    super.key,
    required this.url,
    required this.filename,
  });

  @override
  State<PdfViewerScreen> createState() => _PdfViewerScreenState();
}

class _PdfViewerScreenState extends State<PdfViewerScreen> {
  InAppWebViewController? _controller;
  bool _isLoading = true;
  double _progress = 0.0;

  // Use Google Docs Viewer to render PDF in WebView
  String get _viewerUrl =>
      'https://docs.google.com/viewer?url=${Uri.encodeComponent(widget.url)}&embedded=true';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.filename,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.download_outlined),
            tooltip: 'Download PDF',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Starting download...'),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.open_in_browser_rounded),
            tooltip: 'Open in Browser',
            onPressed: () {
              _controller?.loadUrl(
                urlRequest: URLRequest(url: WebUri(widget.url)),
              );
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          InAppWebView(
            initialUrlRequest:
                URLRequest(url: WebUri(_viewerUrl)),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useOnLoadResource: false,
            ),
            onWebViewCreated: (c) => _controller = c,
            onLoadStart: (_, __) =>
                setState(() => _isLoading = true),
            onLoadStop: (_, __) =>
                setState(() => _isLoading = false),
            onProgressChanged: (_, p) =>
                setState(() => _progress = p / 100),
          ),
          if (_isLoading)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(
                value: _progress > 0 ? _progress : null,
                minHeight: 2,
                backgroundColor: Colors.transparent,
                color: const Color(0xFF0A84FF),
              ),
            ),
        ],
      ),
    );
  }
}
