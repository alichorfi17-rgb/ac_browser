import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../domain/entities/browser_tab.dart';

const _uuid = Uuid();

/// State for the entire browser session
class BrowserState {
  final List<BrowserTab> tabs;
  final int activeTabIndex;
  final bool showTabsOverview;
  final bool isPrivateMode;

  const BrowserState({
    required this.tabs,
    this.activeTabIndex = 0,
    this.showTabsOverview = false,
    this.isPrivateMode = false,
  });

  BrowserTab? get activeTab =>
      tabs.isEmpty ? null : tabs[activeTabIndex.clamp(0, tabs.length - 1)];

  int get tabCount => tabs.length;

  BrowserState copyWith({
    List<BrowserTab>? tabs,
    int? activeTabIndex,
    bool? showTabsOverview,
    bool? isPrivateMode,
  }) {
    return BrowserState(
      tabs: tabs ?? this.tabs,
      activeTabIndex: activeTabIndex ?? this.activeTabIndex,
      showTabsOverview: showTabsOverview ?? this.showTabsOverview,
      isPrivateMode: isPrivateMode ?? this.isPrivateMode,
    );
  }
}

class BrowserNotifier extends StateNotifier<BrowserState> {
  BrowserNotifier()
      : super(BrowserState(
          tabs: [
            BrowserTab(
              id: _uuid.v4(),
              title: 'New Tab',
              url: 'about:blank',
            )
          ],
        ));

  // ─── Tab Management ─────────────────────────────────────────────────────────

  void addNewTab({String url = 'about:blank', bool isPrivate = false}) {
    final newTab = BrowserTab(
      id: _uuid.v4(),
      title: 'New Tab',
      url: url,
      isPrivate: isPrivate || state.isPrivateMode,
    );
    final updatedTabs = [...state.tabs, newTab];
    state = state.copyWith(
      tabs: updatedTabs,
      activeTabIndex: updatedTabs.length - 1,
      showTabsOverview: false,
    );
  }

  void closeTab(String tabId) {
    final tabs = state.tabs.where((t) => t.id != tabId).toList();
    if (tabs.isEmpty) {
      // Always keep at least one tab
      addNewTab();
      return;
    }
    final closedIndex = state.tabs.indexWhere((t) => t.id == tabId);
    var newActiveIndex = state.activeTabIndex;
    if (closedIndex <= newActiveIndex && newActiveIndex > 0) {
      newActiveIndex--;
    }
    state = state.copyWith(
      tabs: tabs,
      activeTabIndex: newActiveIndex.clamp(0, tabs.length - 1),
    );
  }

  void switchToTab(int index) {
    if (index < 0 || index >= state.tabs.length) return;
    state = state.copyWith(
      activeTabIndex: index,
      showTabsOverview: false,
    );
  }

  void reorderTabs(int oldIndex, int newIndex) {
    final tabs = [...state.tabs];
    final tab = tabs.removeAt(oldIndex);
    tabs.insert(newIndex, tab);

    int activeIndex = state.activeTabIndex;
    if (state.activeTabIndex == oldIndex) {
      activeIndex = newIndex;
    } else if (oldIndex < state.activeTabIndex &&
        newIndex >= state.activeTabIndex) {
      activeIndex--;
    } else if (oldIndex > state.activeTabIndex &&
        newIndex <= state.activeTabIndex) {
      activeIndex++;
    }

    state = state.copyWith(tabs: tabs, activeTabIndex: activeIndex);
  }

  // ─── Active Tab Updates ─────────────────────────────────────────────────────

  void updateActiveTab(BrowserTab Function(BrowserTab) updater) {
    if (state.tabs.isEmpty) return;
    final idx = state.activeTabIndex.clamp(0, state.tabs.length - 1);
    final updatedTabs = [...state.tabs];
    updatedTabs[idx] = updater(updatedTabs[idx]);
    state = state.copyWith(tabs: updatedTabs);
  }

  void updateTabById(String tabId, BrowserTab Function(BrowserTab) updater) {
    final idx = state.tabs.indexWhere((t) => t.id == tabId);
    if (idx == -1) return;
    final updatedTabs = [...state.tabs];
    updatedTabs[idx] = updater(updatedTabs[idx]);
    state = state.copyWith(tabs: updatedTabs);
  }

  void setActiveTabUrl(String url) {
    updateActiveTab((tab) {
      tab.url = url;
      tab.lastVisited = DateTime.now();
      return tab;
    });
  }

  void setActiveTabTitle(String title) {
    updateActiveTab((tab) {
      tab.title = title;
      return tab;
    });
  }

  void setActiveTabLoading(bool isLoading, {double progress = 0.0}) {
    updateActiveTab((tab) {
      tab.isLoading = isLoading;
      tab.loadingProgress = progress;
      return tab;
    });
  }

  void setActiveTabProgress(double progress) {
    updateActiveTab((tab) {
      tab.loadingProgress = progress;
      return tab;
    });
  }

  void setActiveTabSecurity(bool isSecure) {
    updateActiveTab((tab) {
      tab.isSecure = isSecure;
      return tab;
    });
  }

  void incrementBlockedAds(String tabId) {
    updateTabById(tabId, (tab) {
      tab.blockedAdsCount++;
      return tab;
    });
  }

  void setCanGoBackForward(bool canGoBack, bool canGoForward) {
    updateActiveTab((tab) {
      tab.canGoBack = canGoBack;
      tab.canGoForward = canGoForward;
      return tab;
    });
  }

  // ─── UI State ───────────────────────────────────────────────────────────────

  void toggleTabsOverview() {
    state = state.copyWith(showTabsOverview: !state.showTabsOverview);
  }

  void hideTabsOverview() {
    state = state.copyWith(showTabsOverview: false);
  }

  void togglePrivateMode() {
    state = state.copyWith(isPrivateMode: !state.isPrivateMode);
  }

  // ─── Navigation ─────────────────────────────────────────────────────────────

  Future<void> navigateBack() async {
    final tab = state.activeTab;
    if (tab?.controller != null && tab!.canGoBack) {
      await tab.controller!.goBack();
    }
  }

  Future<void> navigateForward() async {
    final tab = state.activeTab;
    if (tab?.controller != null && tab!.canGoForward) {
      await tab.controller!.goForward();
    }
  }

  Future<void> reload() async {
    final tab = state.activeTab;
    if (tab?.controller != null) {
      await tab!.controller!.reload();
    }
  }

  Future<void> stopLoading() async {
    final tab = state.activeTab;
    if (tab?.controller != null) {
      await tab!.controller!.stopLoading();
    }
  }

  Future<void> loadUrl(String url) async {
    final tab = state.activeTab;
    if (tab?.controller != null) {
      await tab!.controller!.loadUrl(
        urlRequest: URLRequest(url: WebUri(url)),
      );
    }
  }
}

final browserProvider =
    StateNotifierProvider<BrowserNotifier, BrowserState>((ref) {
  return BrowserNotifier();
});

// Convenience providers
final activeTabProvider = Provider<BrowserTab?>((ref) {
  return ref.watch(browserProvider).activeTab;
});

final tabCountProvider = Provider<int>((ref) {
  return ref.watch(browserProvider).tabCount;
});

final isPrivateModeProvider = Provider<bool>((ref) {
  return ref.watch(browserProvider).isPrivateMode;
});
