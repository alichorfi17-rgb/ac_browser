import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/di/injection.dart';
import '../../../../services/bookmark_service.dart';

class BookmarksState {
  final List<Bookmark> bookmarks;
  final bool isLoading;
  final String? error;

  const BookmarksState({
    this.bookmarks = const [],
    this.isLoading = false,
    this.error,
  });

  BookmarksState copyWith({
    List<Bookmark>? bookmarks,
    bool? isLoading,
    String? error,
  }) =>
      BookmarksState(
        bookmarks: bookmarks ?? this.bookmarks,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}

class BookmarksNotifier extends StateNotifier<BookmarksState> {
  final BookmarkService _service;

  BookmarksNotifier(this._service) : super(const BookmarksState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    try {
      final bookmarks = await _service.getAllBookmarks();
      state = state.copyWith(bookmarks: bookmarks, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> add(String title, String url, {String? favicon}) async {
    await _service.addBookmark(title: title, url: url, favicon: favicon);
    await load();
  }

  Future<void> remove(int id) async {
    await _service.removeBookmark(id);
    await load();
  }

  Future<void> update(int id, String title, String url, String? favicon) async {
    await _service.updateBookmark(id, title, url, favicon);
    await load();
  }

  Future<bool> isBookmarked(String url) => _service.isBookmarked(url);
}

final bookmarksNotifierProvider =
    StateNotifierProvider<BookmarksNotifier, BookmarksState>((ref) {
  return BookmarksNotifier(getIt<BookmarkService>());
});
