import '../entities/bookmark_entity.dart';
import '../repositories/bookmark_repository.dart';

class GetAllBookmarksUseCase {
  final BookmarkRepository _repo;
  GetAllBookmarksUseCase(this._repo);
  Future<List<BookmarkEntity>> call() => _repo.getAll();
}

class SearchBookmarksUseCase {
  final BookmarkRepository _repo;
  SearchBookmarksUseCase(this._repo);
  Future<List<BookmarkEntity>> call(String query) => _repo.search(query);
}

class AddBookmarkUseCase {
  final BookmarkRepository _repo;
  AddBookmarkUseCase(this._repo);
  Future<BookmarkEntity> call(String title, String url, {String? favicon}) =>
      _repo.add(title, url, favicon: favicon);
}

class RemoveBookmarkUseCase {
  final BookmarkRepository _repo;
  RemoveBookmarkUseCase(this._repo);
  Future<void> call(int id) => _repo.remove(id);
}

class UpdateBookmarkUseCase {
  final BookmarkRepository _repo;
  UpdateBookmarkUseCase(this._repo);
  Future<void> call(int id, String title, String url, {String? favicon}) =>
      _repo.update(id, title, url, favicon: favicon);
}

class IsBookmarkedUseCase {
  final BookmarkRepository _repo;
  IsBookmarkedUseCase(this._repo);
  Future<bool> call(String url) => _repo.exists(url);
}
