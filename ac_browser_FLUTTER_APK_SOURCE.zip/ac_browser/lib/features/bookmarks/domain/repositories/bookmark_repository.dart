import '../entities/bookmark_entity.dart';

abstract class BookmarkRepository {
  Future<List<BookmarkEntity>> getAll();
  Future<List<BookmarkEntity>> search(String query);
  Future<BookmarkEntity> add(String title, String url, {String? favicon});
  Future<void> remove(int id);
  Future<void> update(int id, String title, String url, {String? favicon});
  Future<bool> exists(String url);
}
