import '../../../../database/database_helper.dart';
import '../../domain/entities/bookmark_entity.dart';

class BookmarksDataSource {
  final DatabaseHelper _db;

  BookmarksDataSource(this._db);

  Future<List<BookmarkEntity>> getAll() async {
    final maps = await _db.getAllBookmarks();
    return maps.map(_fromMap).toList();
  }

  Future<List<BookmarkEntity>> search(String query) async {
    final maps = await _db.searchBookmarks(query);
    return maps.map(_fromMap).toList();
  }

  Future<int> insert(
      String title, String url, String? favicon) async {
    return await _db.insertBookmark({
      'title': title,
      'url': url,
      if (favicon != null) 'favicon': favicon,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> delete(int id) => _db.deleteBookmark(id);

  Future<bool> exists(String url) => _db.isBookmarked(url);

  Future<void> update(
      int id, String title, String url, String? favicon) async {
    await _db.updateBookmark(id, {
      'title': title,
      'url': url,
      if (favicon != null) 'favicon': favicon,
    });
  }

  BookmarkEntity _fromMap(Map<String, dynamic> m) => BookmarkEntity(
        id: m['id'] as int?,
        title: m['title'] as String,
        url: m['url'] as String,
        favicon: m['favicon'] as String?,
        createdAt: DateTime.tryParse(m['created_at'] as String? ?? '') ??
            DateTime.now(),
      );
}
