import '../../domain/entities/bookmark_entity.dart';
import '../../domain/repositories/bookmark_repository.dart';
import '../datasources/bookmarks_datasource.dart';

class BookmarkRepositoryImpl implements BookmarkRepository {
  final BookmarksDataSource _dataSource;

  BookmarkRepositoryImpl(this._dataSource);

  @override
  Future<List<BookmarkEntity>> getAll() => _dataSource.getAll();

  @override
  Future<List<BookmarkEntity>> search(String query) =>
      _dataSource.search(query);

  @override
  Future<BookmarkEntity> add(String title, String url,
      {String? favicon}) async {
    final id = await _dataSource.insert(title, url, favicon);
    return BookmarkEntity(
      id: id,
      title: title,
      url: url,
      favicon: favicon,
      createdAt: DateTime.now(),
    );
  }

  @override
  Future<void> remove(int id) => _dataSource.delete(id);

  @override
  Future<void> update(int id, String title, String url,
      {String? favicon}) =>
      _dataSource.update(id, title, url, favicon);

  @override
  Future<bool> exists(String url) => _dataSource.exists(url);
}
