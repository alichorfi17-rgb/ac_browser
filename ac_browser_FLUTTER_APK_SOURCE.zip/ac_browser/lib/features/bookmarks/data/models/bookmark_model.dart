import '../../domain/entities/bookmark_entity.dart';

/// Data model for bookmark stored in SQLite
class BookmarkDataModel {
  final int? id;
  final String title;
  final String url;
  final String? favicon;
  final String createdAt;

  const BookmarkDataModel({
    this.id,
    required this.title,
    required this.url,
    this.favicon,
    required this.createdAt,
  });

  factory BookmarkDataModel.fromMap(Map<String, dynamic> map) =>
      BookmarkDataModel(
        id: map['id'] as int?,
        title: map['title'] as String,
        url: map['url'] as String,
        favicon: map['favicon'] as String?,
        createdAt: map['created_at'] as String? ??
            DateTime.now().toIso8601String(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'title': title,
        'url': url,
        if (favicon != null) 'favicon': favicon,
        'created_at': createdAt,
      };

  BookmarkEntity toEntity() => BookmarkEntity(
        id: id,
        title: title,
        url: url,
        favicon: favicon,
        createdAt: DateTime.tryParse(createdAt) ?? DateTime.now(),
      );

  factory BookmarkDataModel.fromEntity(BookmarkEntity entity) =>
      BookmarkDataModel(
        id: entity.id,
        title: entity.title,
        url: entity.url,
        favicon: entity.favicon,
        createdAt: entity.createdAt.toIso8601String(),
      );
}
