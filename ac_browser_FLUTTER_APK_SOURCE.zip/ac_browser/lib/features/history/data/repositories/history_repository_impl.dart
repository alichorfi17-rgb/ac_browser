import '../../domain/entities/history_entity.dart';
import '../../domain/repositories/history_repository.dart';
import '../datasources/history_datasource.dart';

class HistoryRepositoryImpl implements HistoryRepository {
  final HistoryDataSource _dataSource;

  HistoryRepositoryImpl(this._dataSource);

  @override
  Future<List<HistoryEntity>> getRecent({int limit = 100}) =>
      _dataSource.getRecent(limit: limit);

  @override
  Future<List<HistoryEntity>> search(String query) =>
      _dataSource.search(query);

  @override
  Future<void> add(String url, {String? title, bool isPrivate = false}) async {
    if (isPrivate) return;
    if (url == 'about:blank' || url.isEmpty) return;
    await _dataSource.insert(url, title: title);
  }

  @override
  Future<void> delete(int id) => _dataSource.delete(id);

  @override
  Future<void> clearAll() => _dataSource.clearAll();
}
