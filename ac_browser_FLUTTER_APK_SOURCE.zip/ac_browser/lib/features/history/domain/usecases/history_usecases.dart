import '../entities/history_entity.dart';
import '../repositories/history_repository.dart';

class GetRecentHistoryUseCase {
  final HistoryRepository _repo;
  GetRecentHistoryUseCase(this._repo);
  Future<List<HistoryEntity>> call({int limit = 100}) =>
      _repo.getRecent(limit: limit);
}

class SearchHistoryUseCase {
  final HistoryRepository _repo;
  SearchHistoryUseCase(this._repo);
  Future<List<HistoryEntity>> call(String query) => _repo.search(query);
}

class AddHistoryUseCase {
  final HistoryRepository _repo;
  AddHistoryUseCase(this._repo);
  Future<void> call(String url, {String? title, bool isPrivate = false}) =>
      _repo.add(url, title: title, isPrivate: isPrivate);
}

class DeleteHistoryItemUseCase {
  final HistoryRepository _repo;
  DeleteHistoryItemUseCase(this._repo);
  Future<void> call(int id) => _repo.delete(id);
}

class ClearAllHistoryUseCase {
  final HistoryRepository _repo;
  ClearAllHistoryUseCase(this._repo);
  Future<void> call() => _repo.clearAll();
}
