/// Domain entity for a browsing history item
class HistoryEntity {
  final int? id;
  final String? title;
  final String url;
  final DateTime visitTime;

  const HistoryEntity({
    this.id,
    this.title,
    required this.url,
    required this.visitTime,
  });

  String get displayTitle => title?.isNotEmpty == true ? title! : url;

  @override
  String toString() =>
      'HistoryEntity(id: $id, url: $url, visitTime: $visitTime)';
}

/// Abstract repository contract
abstract class HistoryRepository {
  Future<List<HistoryEntity>> getRecent({int limit = 100});
  Future<List<HistoryEntity>> search(String query);
  Future<void> add(String url, {String? title, bool isPrivate = false});
  Future<void> delete(int id);
  Future<void> clearAll();
}
