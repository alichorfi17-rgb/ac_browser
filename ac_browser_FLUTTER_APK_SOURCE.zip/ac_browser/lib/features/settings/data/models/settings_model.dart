import 'package:flutter/material.dart';

/// Data model for settings (key-value pair stored in SQLite)
class SettingModel {
  final int? id;
  final String key;
  final String value;

  const SettingModel({
    this.id,
    required this.key,
    required this.value,
  });

  factory SettingModel.fromMap(Map<String, dynamic> map) => SettingModel(
        id: map['id'] as int?,
        key: map['key'] as String,
        value: map['value'] as String,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'key': key,
        'value': value,
      };

  @override
  String toString() => 'SettingModel(key: $key, value: $value)';
}

/// Extension to convert settings map to typed values
extension SettingsMapX on Map<String, String> {
  ThemeMode get themeMode {
    switch (this['theme']) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  String get searchEngine => this['search_engine'] ?? 'google';
  bool get adBlockEnabled => (this['adblock_enabled'] ?? 'true') == 'true';
  double get fontSize =>
      double.tryParse(this['font_size'] ?? '16') ?? 16.0;
  bool get javascriptEnabled =>
      (this['javascript_enabled'] ?? 'true') == 'true';
  bool get cookiesEnabled => (this['cookies_enabled'] ?? 'true') == 'true';
  bool get safeBrowsing => (this['safe_browsing'] ?? 'true') == 'true';
  bool get savePasswords => (this['save_passwords'] ?? 'false') == 'true';
}
