import 'package:flutter/material.dart';

import '../../domain/repositories/settings_repository.dart';
import '../datasources/settings_datasource.dart';

class SettingsRepositoryImpl implements SettingsRepository {
  final SettingsDataSource _dataSource;

  SettingsRepositoryImpl(this._dataSource);

  @override
  Future<String?> get(String key) => _dataSource.get(key);

  @override
  Future<void> set(String key, String value) => _dataSource.set(key, value);

  @override
  Future<ThemeMode> getTheme() async {
    final v = await _dataSource.get('theme') ?? 'system';
    switch (v) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  @override
  Future<String> getSearchEngine() async =>
      await _dataSource.get('search_engine') ?? 'google';

  @override
  Future<bool> getAdBlockEnabled() async =>
      (await _dataSource.get('adblock_enabled') ?? 'true') == 'true';

  @override
  Future<double> getFontSize() async =>
      double.tryParse(await _dataSource.get('font_size') ?? '16') ?? 16.0;

  @override
  Future<bool> getJavascriptEnabled() async =>
      (await _dataSource.get('javascript_enabled') ?? 'true') == 'true';

  @override
  Future<bool> getCookiesEnabled() async =>
      (await _dataSource.get('cookies_enabled') ?? 'true') == 'true';

  @override
  Future<bool> getSafeBrowsing() async =>
      (await _dataSource.get('safe_browsing') ?? 'true') == 'true';
}
