import 'package:flutter/material.dart';

abstract class SettingsRepository {
  Future<String?> get(String key);
  Future<void> set(String key, String value);
  Future<ThemeMode> getTheme();
  Future<String> getSearchEngine();
  Future<bool> getAdBlockEnabled();
  Future<double> getFontSize();
  Future<bool> getJavascriptEnabled();
  Future<bool> getCookiesEnabled();
  Future<bool> getSafeBrowsing();
}
