import 'package:flutter/material.dart';

import '../../../../services/settings_service.dart';

class LoadSettingsUseCase {
  final SettingsService _service;
  LoadSettingsUseCase(this._service);
  Future<BrowserSettings> call() => _service.loadSettings();
}

class SaveThemeUseCase {
  final SettingsService _service;
  SaveThemeUseCase(this._service);
  Future<void> call(ThemeMode mode) => _service.saveTheme(mode);
}

class SaveSearchEngineUseCase {
  final SettingsService _service;
  SaveSearchEngineUseCase(this._service);
  Future<void> call(String engine) => _service.saveSearchEngine(engine);
}

class SaveAdBlockEnabledUseCase {
  final SettingsService _service;
  SaveAdBlockEnabledUseCase(this._service);
  Future<void> call(bool enabled) => _service.saveAdBlockEnabled(enabled);
}
